package com.bikeinsurance.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VehicleDTO {
    private String vehicleNumber;
    private Integer vehicleYear;
    private Integer noOfDrivingAccidents;
    private Integer noOfDrivingViolations;
    private String coverageType;
    private Double coverageAmount;
    private Double coverageDeductibles;
}
