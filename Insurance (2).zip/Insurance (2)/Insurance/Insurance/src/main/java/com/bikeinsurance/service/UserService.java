package com.bikeinsurance.service;

import com.bikeinsurance.model.User;
import com.bikeinsurance.dto.UserDTO;
import com.bikeinsurance.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.UUID;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Save a new user
    public User saveUser(UserDTO userDTO) {
        User user = new User();
        user.setUserId(UUID.randomUUID().toString()); // generate unique userId
        user.setName(userDTO.getName());
        user.setEmail(userDTO.getEmail());
        user.setPhone(userDTO.getPhone());
        return userRepository.save(user);
    }

    // Get user by database ID
    public User getUserById(Long userId) {
        return userRepository.findByUserId(userId).orElse(null);
    }

    // Get user by email
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    // **Get user by userId (needed for controller)**
    public User getUserByUserId(Long userId) {
        return userRepository.findByUserId(userId);
    }

    // **Update user fields**
    public User updateUser(Long userId, Map<String, String> updates) {
        User user = userRepository.findByUserId(userId);
        if (user == null) return null;

        if (updates.containsKey("name")) {
            user.setName(updates.get("name"));
        }
        if (updates.containsKey("email")) {
            user.setEmail(updates.get("email"));
        }
        if (updates.containsKey("phone")) {
            user.setPhone(updates.get("phone"));
        }

        return userRepository.save(user);
    }
}
