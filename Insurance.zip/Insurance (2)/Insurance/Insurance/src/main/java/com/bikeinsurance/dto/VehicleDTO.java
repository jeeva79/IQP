package com.bikeinsurance.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class VehicleDTO {
    private String userId;  // Added field
    private String vehicleNumber;
    private Integer vehicleYear;
    private Integer noOfDrivingAccidents;
    private Integer noOfDrivingViolations;
    private String coverageType;
    private Double coverageAmount;
    private Double coverageDeductibles;
    
    public String getUserId() {
        return userId;
    }
    
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public String getVehicleNumber() {
        return vehicleNumber;
    }
    
    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }
    
    public Integer getVehicleYear() {
        return vehicleYear;
    }
    
    public void setVehicleYear(Integer vehicleYear) {
        this.vehicleYear = vehicleYear;
    }
    
    public Integer getNoOfDrivingAccidents() {
        return noOfDrivingAccidents;
    }
    
    public void setNoOfDrivingAccidents(Integer noOfDrivingAccidents) {
        this.noOfDrivingAccidents = noOfDrivingAccidents;
    }
    
    public Integer getNoOfDrivingViolations() {
        return noOfDrivingViolations;
    }
    
    public void setNoOfDrivingViolations(Integer noOfDrivingViolations) {
        this.noOfDrivingViolations = noOfDrivingViolations;
    }
    
    public String getCoverageType() {
        return coverageType;
    }
    
    public void setCoverageType(String coverageType) {
        this.coverageType = coverageType;
    }
    
    public Double getCoverageAmount() {
        return coverageAmount;
    }
    
    public void setCoverageAmount(Double coverageAmount) {
        this.coverageAmount = coverageAmount;
    }
    
    public Double getCoverageDeductibles() {
        return coverageDeductibles;
    }
    
    public void setCoverageDeductibles(Double coverageDeductibles) {
        this.coverageDeductibles = coverageDeductibles;
    }
}