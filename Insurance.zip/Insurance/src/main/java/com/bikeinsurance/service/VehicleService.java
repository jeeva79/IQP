package com.bikeinsurance.service;

import com.bikeinsurance.model.Vehicle;
import com.bikeinsurance.dto.VehicleDTO;
import com.bikeinsurance.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehicleService {
    @Autowired
    private VehicleRepository vehicleRepository;
    
    public Vehicle saveVehicle(VehicleDTO vehicleDTO) {
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleNumber(vehicleDTO.getVehicleNumber());
        vehicle.setVehicleYear(vehicleDTO.getVehicleYear());
        vehicle.setNoOfDrivingAccidents(vehicleDTO.getNoOfDrivingAccidents());
        vehicle.setNoOfDrivingViolations(vehicleDTO.getNoOfDrivingViolations());
        vehicle.setCoverageType(vehicleDTO.getCoverageType());
        vehicle.setCoverageAmount(vehicleDTO.getCoverageAmount());
        vehicle.setCoverageDeductibles(vehicleDTO.getCoverageDeductibles());
        return vehicleRepository.save(vehicle);
    }
    
    public Vehicle getVehicleById(Long id) {
        return vehicleRepository.findById(id).orElse(null);
    }
}
