import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { InsuranceQuote, InsuranceApplication } from '../models/insurance-quote.model';
import { ApiResponse } from '../models/api-response.model';

@Injectable({
  providedIn: 'root'
})
export class InsuranceService {
  private apiUrl = 'http://localhost:8080/api/insurance';

  constructor(private http: HttpClient) {}

  getQuotes(vehicleId: number): Observable<InsuranceQuote[]> {
    return this.http.get<ApiResponse<InsuranceQuote[]>>(`${this.apiUrl}/calculate/${vehicleId}`)
      .pipe(map(response => {
        if (response.success && response.quotes) {
          return response.quotes;
        }
        throw new Error(response.message || 'Failed to fetch quotes');
      }));
  }

  selectProvider(application: InsuranceApplication): Observable<number> {
    return this.http.post<ApiResponse<any>>(`${this.apiUrl}/select-provider`, application)
      .pipe(map(response => {
        if (response.success && response.quoteId) {
          return response.quoteId;
        }
        throw new Error(response.message || 'Failed to select provider');
      }));
  }
}

