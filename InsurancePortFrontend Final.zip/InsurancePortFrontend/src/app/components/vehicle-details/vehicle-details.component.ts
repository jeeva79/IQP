// src/app/components/vehicle-details/vehicle-details.component.ts
// REPLACE ENTIRE FILE
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { VehicleService } from '../../services/vehicle.service';
import { Vehicle } from '../../models/vehicle.model';

@Component({
  selector: 'app-vehicle-details',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="details-container">
      <div class="back-button" (click)="goBack()">
        <i class="bi bi-arrow-left"></i> Back to Home
      </div>

      <div class="details-card" *ngIf="vehicle && !loading">
        <div class="card-header">
          <div class="vehicle-icon">
            <i class="bi bi-bicycle"></i>
          </div>
          <div>
            <h2>Vehicle Details</h2>
            <p class="vehicle-number">{{ vehicle.vehicleNumber }}</p>
          </div>
        </div>

        <div class="card-body">
          <!-- Basic Information -->
          <div class="info-section">
            <div class="section-title">
              <i class="bi bi-info-circle-fill"></i>
              <h3>Basic Information</h3>
            </div>
            <div class="info-grid">
              <div class="info-item">
                <label>Vehicle Number</label>
                <span class="value highlight">{{ vehicle.vehicleNumber }}</span>
              </div>
              <div class="info-item">
                <label>Vehicle Year</label>
                <span class="value">{{ vehicle.vehicleYear }}</span>
              </div>
              <div class="info-item">
                <label>Owner ID</label>
                <span class="value">{{ vehicle.userId }}</span>
              </div>
            </div>
          </div>

          <!-- Coverage Information -->
          <div class="info-section">
            <div class="section-title">
              <i class="bi bi-shield-fill-check"></i>
              <h3>Coverage Information</h3>
            </div>
            <div class="info-grid">
              <div class="info-item">
                <label>Coverage Type</label>
                <span class="value badge" 
                  [class.comprehensive]="vehicle.coverageType === 'Comprehensive'"
                  [class.third-party]="vehicle.coverageType === 'Third Party'">
                  {{ vehicle.coverageType }}
                </span>
              </div>
              <div class="info-item">
                <label>Coverage Amount</label>
                <span class="value price">₹{{ vehicle.coverageAmount | number:'1.2-2' }}</span>
              </div>
              <div class="info-item">
                <label>Coverage Deductibles</label>
                <span class="value price">₹{{ vehicle.coverageDeductibles | number:'1.2-2' }}</span>
              </div>
            </div>
          </div>

          <!-- Driving Record -->
          <div class="info-section">
            <div class="section-title">
              <i class="bi bi-exclamation-triangle-fill"></i>
              <h3>Driving Record</h3>
            </div>
            <div class="info-grid">
              <div class="info-item">
                <label>Number of Accidents</label>
                <span class="value" [class.warning]="vehicle.noOfDrivingAccidents > 0">
                  <i class="bi bi-car-front-fill"></i>
                  {{ vehicle.noOfDrivingAccidents }}
                </span>
              </div>
              <div class="info-item">
                <label>Number of Violations</label>
                <span class="value" [class.warning]="vehicle.noOfDrivingViolations > 0">
                  <i class="bi bi-exclamation-octagon-fill"></i>
                  {{ vehicle.noOfDrivingViolations }}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div class="card-footer">
          <button class="action-btn edit-btn" (click)="editVehicle()">
            <i class="bi bi-pencil-square"></i>
            Edit Vehicle Information
          </button>
          <button class="action-btn quote-btn" (click)="getQuotes()">
            <i class="bi bi-calculator-fill"></i>
            Get Price / Insurance
          </button>
        </div>
      </div>

      <!-- Loading State -->
      <div *ngIf="loading" class="loading-container">
        <div class="spinner-border"></div>
        <p>Loading vehicle details...</p>
      </div>

      <!-- Error State -->
      <div *ngIf="errorMessage && !loading" class="error-container">
        <i class="bi bi-exclamation-circle-fill"></i>
        <h3>Error Loading Vehicle</h3>
        <p>{{ errorMessage }}</p>
        <button class="back-btn" (click)="goBack()">
          <i class="bi bi-arrow-left"></i> Go Back
        </button>
      </div>
    </div>
  `,
  styles: [`
    .details-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 40px 20px;
      position: relative;
    }

    .back-button {
      max-width: 1000px;
      margin: 0 auto 20px;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 12px 24px;
      background: rgba(255,255,255,0.2);
      backdrop-filter: blur(10px);
      color: white;
      border: none;
      border-radius: 50px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .back-button:hover {
      background: rgba(255,255,255,0.3);
      transform: translateX(-5px);
    }

    .details-card {
      max-width: 1000px;
      margin: 0 auto;
      background: white;
      border-radius: 25px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      overflow: hidden;
      animation: slideUp 0.6s ease;
    }

    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .card-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 40px;
      display: flex;
      align-items: center;
      gap: 25px;
    }

    .vehicle-icon {
      width: 90px;
      height: 90px;
      background: rgba(255,255,255,0.2);
      backdrop-filter: blur(10px);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      box-shadow: 0 5px 20px rgba(0,0,0,0.2);
    }

    .vehicle-icon i {
      font-size: 3rem;
    }

    .card-header h2 {
      font-size: 2.2rem;
      font-weight: 700;
      margin: 0 0 8px;
    }

    .vehicle-number {
      font-size: 1.4rem;
      font-weight: 600;
      opacity: 0.95;
      margin: 0;
      letter-spacing: 1px;
    }

    .card-body {
      padding: 45px;
    }

    .info-section {
      margin-bottom: 40px;
      padding: 30px;
      background: #f8f9fa;
      border-radius: 20px;
      border: 2px solid #e9ecef;
    }

    .section-title {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-bottom: 25px;
      padding-bottom: 15px;
      border-bottom: 3px solid #667eea;
    }

    .section-title i {
      font-size: 1.8rem;
      color: #667eea;
    }

    .section-title h3 {
      font-size: 1.5rem;
      font-weight: 700;
      color: #333;
      margin: 0;
    }

    .info-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 25px;
    }

    .info-item {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .info-item label {
      font-size: 0.95rem;
      color: #666;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .info-item .value {
      font-size: 1.3rem;
      font-weight: 700;
      color: #333;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .value.highlight {
      color: #667eea;
      font-size: 1.5rem;
    }

    .value.price {
      color: #4caf50;
    }

    .value.badge {
      display: inline-block;
      padding: 10px 20px;
      border-radius: 50px;
      font-size: 1.1rem;
      width: fit-content;
      color: white;
    }

    .value.badge.comprehensive {
      background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
      box-shadow: 0 3px 15px rgba(76,175,80,0.3);
    }

    .value.badge.third-party {
      background: linear-gradient(135deg, #ff9800 0%, #ffa726 100%);
      box-shadow: 0 3px 15px rgba(255,152,0,0.3);
    }

    .value.warning {
      color: #ff6b6b;
    }

    .card-footer {
      padding: 35px 45px;
      background: #f8f9fa;
      display: flex;
      gap: 20px;
      justify-content: center;
      flex-wrap: wrap;
    }

    .action-btn {
      padding: 18px 35px;
      border: none;
      border-radius: 50px;
      font-size: 1.1rem;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .edit-btn {
      background: white;
      color: #667eea;
      border: 3px solid #667eea;
    }

    .edit-btn:hover {
      background: #667eea;
      color: white;
      transform: translateY(-3px);
      box-shadow: 0 10px 30px rgba(102,126,234,0.4);
    }

    .quote-btn {
      background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
      color: white;
      box-shadow: 0 5px 20px rgba(76,175,80,0.3);
    }

    .quote-btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 10px 30px rgba(76,175,80,0.5);
    }

    .loading-container, .error-container {
      max-width: 600px;
      margin: 0 auto;
      text-align: center;
      color: white;
      padding: 60px 20px;
      animation: fadeIn 0.5s ease;
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    .loading-container p, .error-container p {
      font-size: 1.3rem;
      margin-top: 25px;
      font-weight: 500;
    }

    .error-container i {
      font-size: 5rem;
      margin-bottom: 25px;
      animation: shake 0.5s ease;
    }

    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-10px); }
      75% { transform: translateX(10px); }
    }

    .error-container h3 {
      font-size: 2rem;
      font-weight: 700;
      margin-bottom: 15px;
    }

    .spinner-border {
      width: 4rem;
      height: 4rem;
      border: 5px solid rgba(255,255,255,0.3);
      border-top-color: white;
    }

    .back-btn {
      margin-top: 25px;
      padding: 15px 35px;
      background: white;
      color: #667eea;
      border: none;
      border-radius: 50px;
      font-size: 1.1rem;
      font-weight: 700;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 10px;
      transition: all 0.3s ease;
    }

    .back-btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    }

    @media (max-width: 768px) {
      .card-header {
        flex-direction: column;
        text-align: center;
        padding: 30px 25px;
      }

      .card-body {
        padding: 30px 20px;
      }

      .info-section {
        padding: 20px;
      }

      .card-footer {
        flex-direction: column;
        padding: 25px 20px;
      }

      .action-btn {
        width: 100%;
        justify-content: center;
      }
    }
  `]
})
export class VehicleDetailsComponent implements OnInit {
  vehicle: Vehicle | null = null;
  loading: boolean = false;
  errorMessage: string = '';

  constructor(
    private vehicleService: VehicleService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const vehicleNumber = params['vehicleNumber'];
      if (vehicleNumber) {
        this.loadVehicleDetails(vehicleNumber);
      } else {
        this.errorMessage = 'No vehicle number provided';
      }
    });
  }

  loadVehicleDetails(vehicleNumber: string): void {
    this.loading = true;
    this.errorMessage = '';

    this.vehicleService.getVehicleByNumber(vehicleNumber).subscribe({
      next: (data) => {
        console.log('✅ Vehicle loaded:', data);
        this.vehicle = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('❌ Load error:', err);
        this.errorMessage = 'Failed to load vehicle details';
        this.loading = false;
      }
    });
  }

  editVehicle(): void {
    if (this.vehicle) {
      this.router.navigate(['/vehicle-form'], {
        queryParams: {
          vehicleNumber: this.vehicle.vehicleNumber,
          userId: this.vehicle.userId,
          update: 'true'
        }
      });
    }
  }

  getQuotes(): void {
    if (this.vehicle) {
      this.router.navigate(['/quotes'], {
        queryParams: {
          vehicleNumber: this.vehicle.vehicleNumber,
          userId: this.vehicle.userId
        }
      });
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}