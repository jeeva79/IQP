package com.bikeinsurance.service;

import com.bikeinsurance.model.Vehicle;
import com.bikeinsurance.dto.VehicleDTO;
import com.bikeinsurance.repository.VehicleRepository;
import com.bikeinsurance.util.ValidationUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;

@Service
public class VehicleService {
    @Autowired
    private VehicleRepository vehicleRepository;

    @Autowired
    private UserService userService;

    public Vehicle saveVehicle(VehicleDTO vehicleDTO) {
        // Validate userId
        if (vehicleDTO.getUserId() == null || vehicleDTO.getUserId().trim().isEmpty()) {
            throw new IllegalArgumentException("User ID is required");
        }

        // Verify user exists by UUID string
        if (userService.getUserByUserId(vehicleDTO.getUserId()) == null) {
            throw new IllegalArgumentException("User not found with ID: " + vehicleDTO.getUserId());
        }

        // Validate other fields
        ValidationUtils.validateVehicleNumber(vehicleDTO.getVehicleNumber());
        ValidationUtils.validateVehicleYear(vehicleDTO.getVehicleYear());
        ValidationUtils.validateNonNegativeInteger(vehicleDTO.getNoOfDrivingAccidents(), "Number of driving accidents");
        ValidationUtils.validateNonNegativeInteger(vehicleDTO.getNoOfDrivingViolations(), "Number of driving violations");
        ValidationUtils.validateCoverageType(vehicleDTO.getCoverageType());
        ValidationUtils.validatePositiveDouble(vehicleDTO.getCoverageAmount(), "Coverage amount");
        ValidationUtils.validatePositiveDouble(vehicleDTO.getCoverageDeductibles(), "Coverage deductibles");

        // Check if vehicle number already exists
        Vehicle existingVehicle = vehicleRepository.findByVehicleNumber(vehicleDTO.getVehicleNumber());
        if (existingVehicle != null) {
            throw new IllegalArgumentException("Vehicle with this number already registered");
        }

        Vehicle vehicle = new Vehicle();
        vehicle.setUserId(vehicleDTO.getUserId());
        vehicle.setVehicleNumber(vehicleDTO.getVehicleNumber());
        vehicle.setVehicleYear(vehicleDTO.getVehicleYear());
        vehicle.setNoOfDrivingAccidents(vehicleDTO.getNoOfDrivingAccidents());
        vehicle.setNoOfDrivingViolations(vehicleDTO.getNoOfDrivingViolations());
        vehicle.setCoverageType(vehicleDTO.getCoverageType());
        vehicle.setCoverageAmount(vehicleDTO.getCoverageAmount());
        vehicle.setCoverageDeductibles(vehicleDTO.getCoverageDeductibles());

        return vehicleRepository.save(vehicle);
    }

    public Vehicle getVehicleById(Long id) {
        return vehicleRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Vehicle not found with ID: " + id));
    }

    public Vehicle getVehicleByNumber(String vehicleNumber) {
        ValidationUtils.validateVehicleNumber(vehicleNumber);
        Vehicle vehicle = vehicleRepository.findByVehicleNumber(vehicleNumber);
        if (vehicle == null) {
            throw new IllegalArgumentException("Vehicle not found with number: " + vehicleNumber);
        }
        return vehicle;
    }

    public Vehicle updateVehicle(String vehicleNumber, Map<String, Object> updates) {
        Vehicle vehicle = getVehicleByNumber(vehicleNumber);

        if (updates.containsKey("noOfDrivingAccidents")) {
            Integer accidents = (Integer) updates.get("noOfDrivingAccidents");
            ValidationUtils.validateNonNegativeInteger(accidents, "Number of driving accidents");
            vehicle.setNoOfDrivingAccidents(accidents);
        }

        if (updates.containsKey("noOfDrivingViolations")) {
            Integer violations = (Integer) updates.get("noOfDrivingViolations");
            ValidationUtils.validateNonNegativeInteger(violations, "Number of driving violations");
            vehicle.setNoOfDrivingViolations(violations);
        }

        if (updates.containsKey("coverageType")) {
            String coverageType = (String) updates.get("coverageType");
            ValidationUtils.validateCoverageType(coverageType);
            vehicle.setCoverageType(coverageType);
        }

        if (updates.containsKey("coverageAmount")) {
            Double amount = ((Number) updates.get("coverageAmount")).doubleValue();
            ValidationUtils.validatePositiveDouble(amount, "Coverage amount");
            vehicle.setCoverageAmount(amount);
        }

        if (updates.containsKey("coverageDeductibles")) {
            Double deductibles = ((Number) updates.get("coverageDeductibles")).doubleValue();
            ValidationUtils.validatePositiveDouble(deductibles, "Coverage deductibles");
            vehicle.setCoverageDeductibles(deductibles);
        }

        return vehicleRepository.save(vehicle);
    }
}
