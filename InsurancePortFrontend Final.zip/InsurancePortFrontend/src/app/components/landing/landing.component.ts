import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VehicleService } from '../../services/vehicle.service';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="landing-container">
      <!-- Top Navigation -->
      <div class="top-nav">
        <button class="nav-btn user-btn" (click)="goToUserFlow()">
          <i class="bi bi-person-circle"></i> User
        </button>
        <button class="nav-btn admin-btn" (click)="goToAdminLogin()">
          <i class="bi bi-shield-lock"></i> Admin
        </button>
      </div>

      <!-- Animated Background -->
      <div class="animated-bg">
        <div class="circle circle-1"></div>
        <div class="circle circle-2"></div>
        <div class="circle circle-3"></div>
      </div>

      <!-- Hero Section -->
      <div class="hero-section">
        <div class="hero-content">
          <div class="logo-animation">
            <i class="bi bi-shield-check"></i>
          </div>
          
          <h1 class="main-title">Welcome To Bike Insurance Portal</h1>
          <p class="subtitle">Find the best insurance coverage for your bike in minutes</p>
          
          <!-- Search Section -->
          <div class="search-container">
            <div class="search-box">
              <input 
                type="text" 
                [(ngModel)]="vehicleNumber" 
                class="search-input"
                placeholder="Enter Vehicle Number (e.g., KA01AB1234)"
                (input)="vehicleNumber = vehicleNumber.toUpperCase()"
                (keyup.enter)="searchVehicle()">
              <button class="search-btn" (click)="searchVehicle()" [disabled]="searching || !vehicleNumber">
                <i class="bi bi-search"></i>
                <span>{{ searching ? 'Searching...' : 'Search' }}</span>
              </button>
            </div>
            
            <!-- Not Found Message -->
            <div *ngIf="notFound" class="not-found-message">
              <i class="bi bi-exclamation-circle"></i>
              <h3>Vehicle Not Found</h3>
              <p>This vehicle is not registered in our system</p>
              <button class="register-btn" (click)="goToRegister()">
                <i class="bi bi-plus-circle"></i> Register Vehicle
              </button>
            </div>
          </div>

          <!-- Features -->
          <div class="features">
            <div class="feature-item">
              <div class="feature-icon">
                <i class="bi bi-shield-check"></i>
              </div>
              <h4>Comprehensive Coverage</h4>
              <p>Complete protection</p>
            </div>
            <div class="feature-item">
              <div class="feature-icon">
                <i class="bi bi-lightning-charge"></i>
              </div>
              <h4>Instant Quotes</h4>
              <p>Get quotes in seconds</p>
            </div>
            <div class="feature-item">
              <div class="feature-icon">
                <i class="bi bi-wallet2"></i>
              </div>
              <h4>Best Prices</h4>
              <p>Competitive rates</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Toast Notification -->
      <div *ngIf="showToast" class="toast-notification" [class.error]="toastType === 'error'">
        <i [class]="toastType === 'success' ? 'bi bi-check-circle-fill' : 'bi bi-exclamation-triangle-fill'"></i>
        {{ toastMessage }}
      </div>
    </div>
  `,
  styles: [`
    .landing-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      position: relative;
      overflow: hidden;
    }

    .animated-bg {
      position: absolute;
      width: 100%;
      height: 100%;
      overflow: hidden;
      z-index: 0;
    }

    .circle {
      position: absolute;
      border-radius: 50%;
      background: rgba(255,255,255,0.1);
      animation: float 20s infinite ease-in-out;
    }

    .circle-1 {
      width: 300px;
      height: 300px;
      top: 10%;
      left: 10%;
      animation-delay: 0s;
    }

    .circle-2 {
      width: 200px;
      height: 200px;
      top: 60%;
      right: 10%;
      animation-delay: 2s;
    }

    .circle-3 {
      width: 150px;
      height: 150px;
      bottom: 20%;
      left: 50%;
      animation-delay: 4s;
    }

    @keyframes float {
      0%, 100% {
        transform: translate(0, 0) scale(1);
      }
      25% {
        transform: translate(20px, -20px) scale(1.1);
      }
      50% {
        transform: translate(-20px, 20px) scale(0.9);
      }
      75% {
        transform: translate(20px, 20px) scale(1.05);
      }
    }

    .top-nav {
      position: absolute;
      top: 30px;
      left: 30px;
      display: flex;
      gap: 15px;
      z-index: 10;
    }

    .nav-btn {
      padding: 14px 28px;
      border: none;
      border-radius: 50px;
      font-size: 1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      gap: 10px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.2);
    }

    .user-btn {
      background: white;
      color: #667eea;
    }

    .user-btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    }

    .admin-btn {
      background: linear-gradient(135deg, #ff6b6b 0%, #ff8787 100%);
      color: white;
    }

    .admin-btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 10px 30px rgba(255,107,107,0.5);
    }

    .hero-section {
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      padding: 40px 20px;
      position: relative;
      z-index: 1;
    }

    .hero-content {
      text-align: center;
      max-width: 900px;
      width: 100%;
    }

    .logo-animation {
      width: 120px;
      height: 120px;
      background: rgba(255,255,255,0.2);
      backdrop-filter: blur(10px);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 30px;
      animation: rotate 20s linear infinite;
      box-shadow: 0 10px 40px rgba(0,0,0,0.2);
    }

    .logo-animation i {
      font-size: 4rem;
      color: white;
    }

    @keyframes rotate {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(360deg);
      }
    }

    .main-title {
      font-size: 4rem;
      font-weight: 800;
      color: white;
      margin-bottom: 20px;
      text-shadow: 0 5px 15px rgba(0,0,0,0.2);
      animation: fadeInDown 1s ease;
      letter-spacing: -1px;
    }

    .subtitle {
      font-size: 1.5rem;
      color: rgba(255,255,255,0.95);
      margin-bottom: 50px;
      animation: fadeInUp 1s ease;
      font-weight: 300;
    }

    .search-container {
      animation: fadeIn 1.2s ease;
      margin-bottom: 60px;
    }

    .search-box {
      display: flex;
      gap: 15px;
      max-width: 700px;
      margin: 0 auto 30px;
      padding: 10px;
      background: rgba(255,255,255,0.15);
      backdrop-filter: blur(20px);
      border-radius: 60px;
      box-shadow: 0 15px 50px rgba(0,0,0,0.3);
    }

    .search-input {
      flex: 1;
      padding: 20px 30px;
      border: none;
      border-radius: 50px;
      font-size: 1.1rem;
      background: white;
      color: #333;
      transition: all 0.3s ease;
      font-weight: 500;
    }

    .search-input::placeholder {
      color: #999;
    }

    .search-input:focus {
      outline: none;
      box-shadow: 0 0 0 3px rgba(255,255,255,0.3);
    }

    .search-btn {
      padding: 20px 40px;
      background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
      color: white;
      border: none;
      border-radius: 50px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      gap: 10px;
      box-shadow: 0 5px 20px rgba(76,175,80,0.4);
    }

    .search-btn:hover:not(:disabled) {
      transform: translateY(-3px);
      box-shadow: 0 10px 30px rgba(76,175,80,0.5);
    }

    .search-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .not-found-message {
      background: white;
      padding: 40px;
      border-radius: 25px;
      box-shadow: 0 15px 50px rgba(0,0,0,0.3);
      max-width: 500px;
      margin: 0 auto;
      animation: slideUp 0.5s ease;
    }

    .not-found-message i {
      font-size: 4rem;
      color: #ff6b6b;
      margin-bottom: 20px;
      animation: shake 0.5s ease;
    }

    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-10px); }
      75% { transform: translateX(10px); }
    }

    .not-found-message h3 {
      font-size: 1.8rem;
      color: #333;
      margin-bottom: 10px;
      font-weight: 700;
    }

    .not-found-message p {
      font-size: 1.1rem;
      color: #666;
      margin-bottom: 25px;
    }

    .register-btn {
      padding: 15px 35px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
      border-radius: 50px;
      font-size: 1.1rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      display: inline-flex;
      align-items: center;
      gap: 10px;
      box-shadow: 0 5px 20px rgba(102,126,234,0.4);
    }

    .register-btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 10px 30px rgba(102,126,234,0.5);
    }

    .features {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 30px;
      max-width: 900px;
      margin: 0 auto;
      animation: fadeIn 1.5s ease;
    }

    .feature-item {
      background: rgba(255,255,255,0.15);
      backdrop-filter: blur(20px);
      padding: 30px;
      border-radius: 20px;
      text-align: center;
      transition: all 0.3s ease;
      border: 1px solid rgba(255,255,255,0.2);
    }

    .feature-item:hover {
      transform: translateY(-10px);
      background: rgba(255,255,255,0.25);
      box-shadow: 0 15px 40px rgba(0,0,0,0.2);
    }

    .feature-icon {
      width: 80px;
      height: 80px;
      background: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 20px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.15);
    }

    .feature-icon i {
      font-size: 2.5rem;
      color: #667eea;
    }

    .feature-item h4 {
      font-size: 1.3rem;
      font-weight: 700;
      color: white;
      margin-bottom: 10px;
    }

    .feature-item p {
      font-size: 1rem;
      color: rgba(255,255,255,0.9);
      font-weight: 300;
    }

    @keyframes fadeInDown {
      from {
        opacity: 0;
        transform: translateY(-50px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(50px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @media (max-width: 768px) {
      .main-title {
        font-size: 2.5rem;
      }

      .subtitle {
        font-size: 1.1rem;
      }

      .search-box {
        flex-direction: column;
        gap: 10px;
      }

      .features {
        grid-template-columns: 1fr;
        gap: 20px;
      }

      .top-nav {
        top: 15px;
        left: 15px;
      }
    }
  `]
})
export class LandingComponent {
  vehicleNumber: string = '';
  notFound: boolean = false;
  searching: boolean = false;
  showToast: boolean = false;
  toastMessage: string = '';
  toastType: 'success' | 'error' = 'success';

  constructor(
    private vehicleService: VehicleService,
    private router: Router
  ) {}

  searchVehicle(): void {
    if (!this.vehicleNumber.trim()) {
      this.displayToast('Please enter a vehicle number', 'error');
      return;
    }

    this.searching = true;
    this.notFound = false;

    this.vehicleService.getVehicleByNumber(this.vehicleNumber).subscribe({
      next: (vehicle) => {
        this.searching = false;
        this.displayToast('Vehicle found!', 'success');
        setTimeout(() => {
          this.router.navigate(['/vehicle-details'], {
            queryParams: { vehicleNumber: vehicle.vehicleNumber }
          });
        }, 1000);
      },
      error: () => {
        this.searching = false;
        this.notFound = true;
      }
    });
  }

  goToRegister(): void {
    this.router.navigate(['/vehicle-registration'], {
      queryParams: { vehicleNumber: this.vehicleNumber }
    });
  }

  goToUserFlow(): void {
    this.router.navigate(['/vehicle-registration']);
  }

  goToAdminLogin(): void {
    this.router.navigate(['/admin-login']);
  }

  displayToast(message: string, type: 'success' | 'error'): void {
    this.toastMessage = message;
    this.toastType = type;
    this.showToast = true;
    setTimeout(() => {
      this.showToast = false;
    }, 3000);
  }
}