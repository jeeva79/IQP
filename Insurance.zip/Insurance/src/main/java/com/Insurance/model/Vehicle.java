package com.Insurance.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;

@Entity
@Table(name = "vehicles")
public class Vehicle {

    @Id
    @Column(unique = true, nullable = false)
    private String vehicleNumber;  // PRIMARY KEY

    private String vehicleModel;
    private String vehicleMake;
    private Integer vehicleYear;
    private String vehicleType;
    private String fuelType;

    // ⭐ ADD THIS: Vehicle market value
    private Double vehicleValue;

    // ⭐ ADD-ON COVERS
    private boolean zeroDepreciation;
    private boolean engineProtection;
    private boolean roadsideAssistance;

    // ⭐ Other premium factors
    private int passengerCount;
    private int ncbPercentage;

    // Foreign Key relationship with User
    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonIgnore
    private User user;

    @OneToMany(mappedBy = "vehicle", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<InsuranceQuote> quotes;

    public Vehicle() {}

    public Vehicle(String vehicleNumber, String vehicleModel, String vehicleMake,
                   Integer vehicleYear, String vehicleType, String fuelType) {
        this.vehicleNumber = vehicleNumber;
        this.vehicleModel = vehicleModel;
        this.vehicleMake = vehicleMake;
        this.vehicleYear = vehicleYear;
        this.vehicleType = vehicleType;
        this.fuelType = fuelType;
    }

    // ------------------- Getters & Setters ---------------------
    public String getVehicleNumber() { return vehicleNumber; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }

    public String getVehicleModel() { return vehicleModel; }
    public void setVehicleModel(String vehicleModel) { this.vehicleModel = vehicleModel; }

    public String getVehicleMake() { return vehicleMake; }
    public void setVehicleMake(String vehicleMake) { this.vehicleMake = vehicleMake; }

    public Integer getVehicleYear() { return vehicleYear; }
    public void setVehicleYear(Integer vehicleYear) { this.vehicleYear = vehicleYear; }

    public String getVehicleType() { return vehicleType; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }

    public String getFuelType() { return fuelType; }
    public void setFuelType(String fuelType) { this.fuelType = fuelType; }

    public Double getVehicleValue() { return vehicleValue; }
    public void setVehicleValue(Double vehicleValue) { this.vehicleValue = vehicleValue; }

    public boolean isZeroDepreciation() { return zeroDepreciation; }
    public void setZeroDepreciation(boolean zeroDepreciation) { this.zeroDepreciation = zeroDepreciation; }

    public boolean isEngineProtection() { return engineProtection; }
    public void setEngineProtection(boolean engineProtection) { this.engineProtection = engineProtection; }

    public boolean isRoadsideAssistance() { return roadsideAssistance; }
    public void setRoadsideAssistance(boolean roadsideAssistance) { this.roadsideAssistance = roadsideAssistance; }

    public int getPassengerCount() { return passengerCount; }
    public void setPassengerCount(int passengerCount) { this.passengerCount = passengerCount; }

    public int getNcbPercentage() { return ncbPercentage; }
    public void setNcbPercentage(int ncbPercentage) { this.ncbPercentage = ncbPercentage; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public List<InsuranceQuote> getQuotes() { return quotes; }
    public void setQuotes(List<InsuranceQuote> quotes) { this.quotes = quotes; }
}
