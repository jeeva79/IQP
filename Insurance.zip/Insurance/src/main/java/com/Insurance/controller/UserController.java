package com.Insurance.controller;

import com.Insurance.model.User;
import com.Insurance.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/registerOwner")
    public User registerOwner(@RequestBody User user) {
        return userService.saveUser(user);
    }

    @PutMapping("/updateOwner")
    public User updateOwner(@RequestBody User user) {
        return userService.updateUser(user);
    }

    @DeleteMapping("/deleteOwner/{id}")
    public ResponseEntity<Void> deleteOwnerFields(@PathVariable Long id) {

        Optional<User> userOptional = userService.getUserById(id);

        if (userOptional.isPresent()) {
            User user = userOptional.get();

            // FIXED FIELDS — based on your User.java model
            user.setUserAddress(null);
            user.setEmail(null);
            user.setPhoneNumber(null);

            userService.updateUser(user);
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.notFound().build();
    }

    @GetMapping("/display")
    public List<User> displayAllOwners() {
        return userService.getAllUsers();
    }
}
