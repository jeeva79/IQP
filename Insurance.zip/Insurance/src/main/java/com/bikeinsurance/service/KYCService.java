package com.bikeinsurance.service;

import com.bikeinsurance.model.KYC;
import com.bikeinsurance.model.InsuranceQuote;
import com.bikeinsurance.repository.KYCRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

@Service
public class KYCService {
    @Autowired
    private KYCRepository kycRepository;

    private static final String UPLOAD_DIR = "uploads/kyc/";
    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024;

    public KYC uploadKYC(Long insuranceQuoteId, MultipartFile drivingLicense, 
                         MultipartFile rc, MultipartFile aadhar, 
                         InsuranceQuoteService quoteService) throws IOException {
        validatePDFFile(drivingLicense);
        validatePDFFile(rc);
        validatePDFFile(aadhar);

        String dlPath = saveFile(drivingLicense, "DL");
        String rcPath = saveFile(rc, "RC");
        String aadharPath = saveFile(aadhar, "AADHAR");

        KYC kyc = new KYC();
        InsuranceQuote quote = quoteService.getQuoteById(insuranceQuoteId);
        kyc.setInsuranceQuote(quote);
        kyc.setDrivingLicensePath(dlPath);
        kyc.setRcPath(rcPath);
        kyc.setAadharPath(aadharPath);
        kyc.setVerificationStatus("PENDING");
        KYC saved = kycRepository.save(kyc);
        if (quote != null) {
            quote.setKyc(saved);
            quote.setStatus("KYC_UPLOADED");
        }
        return saved;
    }

    private void validatePDFFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("File is required");
        }
        if (!"application/pdf" .equals(file.getContentType())) {
            throw new IllegalArgumentException("Only PDF files are allowed");
        }
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new IllegalArgumentException("File size exceeds 5MB limit");
        }
    }

    private String saveFile(MultipartFile file, String type) throws IOException {
        String fileName = UUID.randomUUID() + "_" + type + ".pdf";
        File uploadDir = new File(UPLOAD_DIR);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }
        File saveFile = new File(uploadDir, fileName);
        file.transferTo(saveFile);
        return UPLOAD_DIR + fileName;
    }
}
