package com.bikeinsurance.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.bikeinsurance.model.InsuranceQuote;
import com.bikeinsurance.model.User;
import java.util.List;

@Repository
public interface InsuranceQuoteRepository extends JpaRepository<InsuranceQuote, Long> {
    InsuranceQuote findByUser(User user);
    List<InsuranceQuote> findAll();
}
