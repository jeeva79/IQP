package com.Insurance.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;

@Entity
@Table(name = "vehicles")
public class Vehicle {

    @Id
    @Column(unique = true, nullable = false)
    private String vehicleNumber;  // PRIMARY KEY

    private String vehicleModel;
    private String vehicleMake;
    private Integer vehicleYear;
    private String vehicleType;
    private String fuelType;

    // Foreign Key relationship with User
    @ManyToOne
    @JoinColumn(name = "user_id")
    @JsonIgnore
    private User user;

    // One vehicle can have multiple quotes
    @OneToMany(mappedBy = "vehicle", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<InsuranceQuote> quotes;

    // Constructors
    public Vehicle() {}

    public Vehicle(String vehicleNumber, String vehicleModel, String vehicleMake,
                   Integer vehicleYear, String vehicleType, String fuelType) {
        this.vehicleNumber = vehicleNumber;
        this.vehicleModel = vehicleModel;
        this.vehicleMake = vehicleMake;
        this.vehicleYear = vehicleYear;
        this.vehicleType = vehicleType;
        this.fuelType = fuelType;
    }

    // Getters and Setters
    public String getVehicleNumber() { return vehicleNumber; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }

    public String getVehicleModel() { return vehicleModel; }
    public void setVehicleModel(String vehicleModel) { this.vehicleModel = vehicleModel; }

    public String getVehicleMake() { return vehicleMake; }
    public void setVehicleMake(String vehicleMake) { this.vehicleMake = vehicleMake; }

    public Integer getVehicleYear() { return vehicleYear; }
    public void setVehicleYear(Integer vehicleYear) { this.vehicleYear = vehicleYear; }

    public String getVehicleType() { return vehicleType; }
    public void setVehicleType(String vehicleType) { this.vehicleType = vehicleType; }

    public String getFuelType() { return fuelType; }
    public void setFuelType(String fuelType) { this.fuelType = fuelType; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public List<InsuranceQuote> getQuotes() { return quotes; }
    public void setQuotes(List<InsuranceQuote> quotes) { this.quotes = quotes; }
}