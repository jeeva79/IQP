package com.bikeinsurance.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminApplicationViewDTO {
    private Long applicationId;
    private String userName;
    private String userEmail;
    private String vehicleNumber;
    private String selectedProvider;
    private String selectedPlan;
    private Double premiumAmount;
    private String kycStatus;
    private String appliedDate;
}
