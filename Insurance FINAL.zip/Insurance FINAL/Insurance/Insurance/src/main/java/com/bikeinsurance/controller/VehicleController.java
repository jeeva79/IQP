package com.bikeinsurance.controller;

import com.bikeinsurance.model.Vehicle;
import com.bikeinsurance.dto.VehicleDTO;
import com.bikeinsurance.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/vehicle")
@CrossOrigin(origins = "*")
public class VehicleController {

    @Autowired
    private VehicleService vehicleService;

    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> registerVehicle(@RequestBody VehicleDTO vehicleDTO) {
        try {
            Vehicle vehicle = vehicleService.saveVehicle(vehicleDTO);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("userId", vehicle.getUserId());
            response.put("vehicleNumber", vehicle.getVehicleNumber());
            response.put("message", "Vehicle registered successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                Map.of("success", false, "message", e.getMessage())
            );
        }
    }

    @GetMapping("/show/{vehicleNumber}")
    public ResponseEntity<Map<String, Object>> showVehicle(@PathVariable String vehicleNumber) {
        try {
            Vehicle vehicle = vehicleService.getVehicleByNumber(vehicleNumber);
            if (vehicle == null) {
                return ResponseEntity.badRequest().body(
                    Map.of("success", false, "message", "Vehicle not found")
                );
            }

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("userId", vehicle.getUserId());
            response.put("vehicleNumber", vehicle.getVehicleNumber());
            response.put("vehicleYear", vehicle.getVehicleYear());
            response.put("noOfDrivingAccidents", vehicle.getNoOfDrivingAccidents());
            response.put("noOfDrivingViolations", vehicle.getNoOfDrivingViolations());
            response.put("coverageType", vehicle.getCoverageType());
            response.put("coverageAmount", vehicle.getCoverageAmount());
            response.put("coverageDeductibles", vehicle.getCoverageDeductibles());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                Map.of("success", false, "message", e.getMessage())
            );
        }
    }

    @PutMapping("/update/{vehicleNumber}")
    public ResponseEntity<Map<String, Object>> updateVehicle(
            @PathVariable String vehicleNumber,
            @RequestBody Map<String, Object> updates) {
        try {
            Vehicle vehicle = vehicleService.updateVehicle(vehicleNumber, updates);
            if (vehicle == null) {
                return ResponseEntity.badRequest().body(
                    Map.of("success", false, "message", "Vehicle not found")
                );
            }

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "Vehicle updated successfully");
            response.put("vehicleNumber", vehicle.getVehicleNumber());
            response.put("userId", vehicle.getUserId());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                Map.of("success", false, "message", e.getMessage())
            );
        }
    }
}
