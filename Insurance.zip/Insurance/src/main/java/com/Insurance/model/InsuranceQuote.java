package com.Insurance.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "insurance_quotes")
public class InsuranceQuote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long quoteId;  // PRIMARY KEY

    private String coverageType;
    private Double coverageAmount;
    private Double coverageDeductibles;
    private Double premiumAmount;
    private String quoteDetails;
    private LocalDateTime createdAt;

    // Foreign Key relationship with User
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    // Foreign Key relationship with Vehicle
    @ManyToOne
    @JoinColumn(name = "vehicle_number", referencedColumnName = "vehicleNumber")
    private Vehicle vehicle;

    // Constructors
    public InsuranceQuote() {
        this.createdAt = LocalDateTime.now();
    }

    public InsuranceQuote(String coverageType, Double coverageAmount,
                          Double coverageDeductibles, Double premiumAmount,
                          String quoteDetails, User user, Vehicle vehicle) {
        this.coverageType = coverageType;
        this.coverageAmount = coverageAmount;
        this.coverageDeductibles = coverageDeductibles;
        this.premiumAmount = premiumAmount;
        this.quoteDetails = quoteDetails;
        this.user = user;
        this.vehicle = vehicle;
        this.createdAt = LocalDateTime.now();
    }

    // Getters and Setters
    public Long getQuoteId() { return quoteId; }
    public void setQuoteId(Long quoteId) { this.quoteId = quoteId; }

    public String getCoverageType() { return coverageType; }
    public void setCoverageType(String coverageType) { this.coverageType = coverageType; }

    public Double getCoverageAmount() { return coverageAmount; }
    public void setCoverageAmount(Double coverageAmount) { this.coverageAmount = coverageAmount; }

    public Double getCoverageDeductibles() { return coverageDeductibles; }
    public void setCoverageDeductibles(Double d) { this.coverageDeductibles = d; }

    public Double getPremiumAmount() { return premiumAmount; }
    public void setPremiumAmount(Double premiumAmount) { this.premiumAmount = premiumAmount; }

    public String getQuoteDetails() { return quoteDetails; }
    public void setQuoteDetails(String quoteDetails) { this.quoteDetails = quoteDetails; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Vehicle getVehicle() { return vehicle; }
    public void setVehicle(Vehicle vehicle) { this.vehicle = vehicle; }
}