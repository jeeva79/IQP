package com.Insurance.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "insurance_quotes")
public class InsuranceQuote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long quoteId;

    private String coverageType;
    private Double coverageAmount;
    private Double coverageDeductibles;
    private Double premiumAmount;
    private String quoteDetails;
    private LocalDateTime createdAt;


    // ------------------------
    // Add-on cover fields
    // ------------------------
    private Boolean zeroDepreciation;
    private Boolean engineProtection;
    private Boolean roadsideAssistance;

    private Integer passengerCount;  // for passenger cover
    private Integer ncbPercentage;   // No Claim Bonus %


    // ------------------------
    // Relations
    // ------------------------
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;

    @ManyToOne
    @JoinColumn(name = "vehicle_number", referencedColumnName = "vehicleNumber")
    private Vehicle vehicle;


    // ------------------------
    // Constructors
    // ------------------------
    public InsuranceQuote() {
        this.createdAt = LocalDateTime.now();
    }


    // ------------------------
    // Getters and Setters
    // ------------------------
    public Long getQuoteId() { return quoteId; }
    public void setQuoteId(Long quoteId) { this.quoteId = quoteId; }

    public String getCoverageType() { return coverageType; }
    public void setCoverageType(String coverageType) { this.coverageType = coverageType; }

    public Double getCoverageAmount() { return coverageAmount; }
    public void setCoverageAmount(Double coverageAmount) { this.coverageAmount = coverageAmount; }

    public Double getCoverageDeductibles() { return coverageDeductibles; }
    public void setCoverageDeductibles(Double coverageDeductibles) { this.coverageDeductibles = coverageDeductibles; }

    public Double getPremiumAmount() { return premiumAmount; }
    public void setPremiumAmount(Double premiumAmount) { this.premiumAmount = premiumAmount; }

    public String getQuoteDetails() { return quoteDetails; }
    public void setQuoteDetails(String quoteDetails) { this.quoteDetails = quoteDetails; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public Boolean getZeroDepreciation() { return zeroDepreciation; }
    public void setZeroDepreciation(Boolean zeroDepreciation) { this.zeroDepreciation = zeroDepreciation; }

    public Boolean getEngineProtection() { return engineProtection; }
    public void setEngineProtection(Boolean engineProtection) { this.engineProtection = engineProtection; }

    public Boolean getRoadsideAssistance() { return roadsideAssistance; }
    public void setRoadsideAssistance(Boolean roadsideAssistance) { this.roadsideAssistance = roadsideAssistance; }

    public Integer getPassengerCount() { return passengerCount; }
    public void setPassengerCount(Integer passengerCount) { this.passengerCount = passengerCount; }

    public Integer getNcbPercentage() { return ncbPercentage; }
    public void setNcbPercentage(Integer ncbPercentage) { this.ncbPercentage = ncbPercentage; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public Vehicle getVehicle() { return vehicle; }
    public void setVehicle(Vehicle vehicle) { this.vehicle = vehicle; }
}
