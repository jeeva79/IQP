package com.bikeinsurance.service;

import com.bikeinsurance.model.*;
import com.bikeinsurance.dto.InsuranceQuoteResponseDTO;
import com.bikeinsurance.repository.InsuranceQuoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class InsuranceQuoteService {
    @Autowired
    private InsuranceQuoteRepository insuranceQuoteRepository;
    @Autowired
    private InsuranceCalculatorService calculatorService;

    public List<InsuranceQuoteResponseDTO> getQuotes(Long vehicleId, VehicleService vehicleService) {
        Vehicle vehicle = vehicleService.getVehicleById(vehicleId);
        List<InsuranceQuoteResponseDTO> quotes = new ArrayList<>();
        quotes.add(calculatorService.calculatePolicyBazaar(vehicle, "Basic"));
        quotes.add(calculatorService.calculateAcko(vehicle, "Basic"));
        quotes.add(calculatorService.calculateIcici(vehicle, "Basic"));
        quotes.add(calculatorService.calculateDigit(vehicle, "Basic"));
        return quotes;
    }
    
    public InsuranceQuote saveQuote(Long userId, Long vehicleId, String provider, 
                                    String plan, Double premium, UserService userService, 
                                    VehicleService vehicleService) {
        InsuranceQuote quote = new InsuranceQuote();
        quote.setUser(userService.getUserById(userId));
        quote.setVehicle(vehicleService.getVehicleById(vehicleId));
        quote.setSelectedProvider(provider);
        quote.setSelectedPlan(plan);
        quote.setPremiumAmount(premium);
        quote.setStatus("PENDING_KYC");
        return insuranceQuoteRepository.save(quote);
    }

    public InsuranceQuote getQuoteById(Long id) {
        return insuranceQuoteRepository.findById(id).orElse(null);
    }

    public List<InsuranceQuote> getAllApplications() {
        return insuranceQuoteRepository.findAll();
    }
}
