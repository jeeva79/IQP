export interface User {
  id?: number;
  userId: string;
  name: string;
  email: string;
  phone: string;
}