// ...existing code...
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { VehicleService } from '../../services/vehicle.service';
import { User } from '../../models/user.model';
import { Vehicle } from '../../models/vehicle.model';

@Component({
  selector: 'app-vehicle-registration',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="registration-container">
      <div class="registration-card">
        <div class="card-header">
          <i class="bi bi-clipboard-check-fill"></i>
          <div>
            <h2>Vehicle Registration</h2>
            <p>Complete the form to register your vehicle and get quotes</p>
          </div>
        </div>

        <form (ngSubmit)="submitRegistration()" #regForm="ngForm">
          <div class="form-sections">
            <!-- Owner Details Section -->
            <div class="form-section">
              <div class="section-header">
                <i class="bi bi-person-circle"></i>
                <h3>Owner Information</h3>
              </div>

              <div class="form-grid">
                <div class="form-group">
                  <label>Full Name *</label>
                  <input 
                    type="text" 
                    [(ngModel)]="user.name" 
                    name="ownerName"
                    class="form-control"
                    placeholder="Enter your full name"
                    required
                    minlength="2"
                    maxlength="100"
                    #ownerName="ngModel">
                  <div *ngIf="ownerName.invalid && ownerName.touched" class="error-msg">
                    <i class="bi bi-exclamation-circle"></i> Name is required (2-100 characters)
                  </div>
                </div>

                <div class="form-group">
                  <label>Email Address *</label>
                  <input 
                    type="email" 
                    [(ngModel)]="user.email" 
                    name="email"
                    class="form-control"
                    placeholder="your@email.com"
                    required
                    email
                    #email="ngModel">
                  <div *ngIf="email.invalid && email.touched" class="error-msg">
                    <i class="bi bi-exclamation-circle"></i> Valid email is required
                  </div>
                </div>

                <div class="form-group">
                  <label>Phone Number *</label>
                  <input 
                    type="tel" 
                    [(ngModel)]="user.phone" 
                    name="phone"
                    class="form-control"
                    placeholder="10-digit mobile number"
                    required
                    pattern="[6-9][0-9]{9}"
                    maxlength="10"
                    #phone="ngModel">
                  <div *ngIf="phone.invalid && phone.touched" class="error-msg">
                    <i class="bi bi-exclamation-circle"></i> Valid 10-digit phone required (6-9)
                  </div>
                </div>
              </div>
            </div>

            <!-- Vehicle Details Section -->
            <div class="form-section">
              <div class="section-header">
                <i class="bi bi-bicycle"></i>
                <h3>Vehicle Information</h3>
              </div>

              <div class="form-grid">
                <div class="form-group">
                  <label>Vehicle Number *</label>
                  <input 
                    type="text" 
                    [(ngModel)]="vehicle.vehicleNumber" 
                    name="vehicleNumber"
                    class="form-control"
                    placeholder="e.g., KA01AB1234"
                    required
                    pattern="[A-Z]{2}[0-9]{2}[A-Z]{1,2}[0-9]{4}"
                    (input)="vehicle.vehicleNumber = vehicle.vehicleNumber.toUpperCase()"
                    #vehicleNumber="ngModel">
                  <div *ngIf="vehicleNumber.invalid && vehicleNumber.touched" class="error-msg">
                    <i class="bi bi-exclamation-circle"></i> Format: KA01AB1234
                  </div>
                </div>

                <div class="form-group">
                  <label>Vehicle Year *</label>
                  <input 
                    type="number" 
                    [(ngModel)]="vehicle.vehicleYear" 
                    name="vehicleYear"
                    class="form-control"
                    placeholder="e.g., 2020"
                    required
                    [min]="1900"
                    [max]="currentYear"
                    #vehicleYear="ngModel">
                  <div *ngIf="vehicleYear.invalid && vehicleYear.touched" class="error-msg">
                    <i class="bi bi-exclamation-circle"></i> Year: 1900-{{currentYear}}
                  </div>
                </div>

                <div class="form-group">
                  <label>Coverage Type *</label>
                  <select 
                    [(ngModel)]="vehicle.coverageType" 
                    name="coverageType"
                    class="form-control"
                    required
                    #coverageType="ngModel">
                    <option value="">-- Select Coverage --</option>
                    <option value="Comprehensive">Comprehensive</option>
                    <option value="Third Party">Third Party</option>
                  </select>
                  <div *ngIf="coverageType.invalid && coverageType.touched" class="error-msg">
                    <i class="bi bi-exclamation-circle"></i> Coverage type required
                  </div>
                </div>

                <div class="form-group">
                  <label>Coverage Amount (₹) *</label>
                  <input 
                    type="number" 
                    [(ngModel)]="vehicle.coverageAmount" 
                    name="coverageAmount"
                    class="form-control"
                    placeholder="e.g., 100000"
                    required
                    min="1"
                    #coverageAmount="ngModel">
                  <div *ngIf="coverageAmount.invalid && coverageAmount.touched" class="error-msg">
                    <i class="bi bi-exclamation-circle"></i> Amount must be > 0
                  </div>
                </div>

                <div class="form-group">
                  <label>Deductibles (₹) *</label>
                  <input 
                    type="number" 
                    [(ngModel)]="vehicle.coverageDeductibles" 
                    name="deductibles"
                    class="form-control"
                    placeholder="e.g., 5000"
                    required
                    min="1"
                    #deductibles="ngModel">
                  <div *ngIf="deductibles.invalid && deductibles.touched" class="error-msg">
                    <i class="bi bi-exclamation-circle"></i> Deductibles must be > 0
                  </div>
                </div>

                <div class="form-group">
                  <label>Number of Accidents *</label>
                  <input 
                    type="number" 
                    [(ngModel)]="vehicle.noOfDrivingAccidents" 
                    name="accidents"
                    class="form-control"
                    required
                    min="0"
                    #accidents="ngModel">
                  <div *ngIf="accidents.invalid && accidents.touched" class="error-msg">
                    <i class="bi bi-exclamation-circle"></i> Cannot be negative
                  </div>
                </div>

                <div class="form-group">
                  <label>Number of Violations *</label>
                  <input 
                    type="number" 
                    [(ngModel)]="vehicle.noOfDrivingViolations" 
                    name="violations"
                    class="form-control"
                    required
                    min="0"
                    #violations="ngModel">
                  <div *ngIf="violations.invalid && violations.touched" class="error-msg">
                    <i class="bi bi-exclamation-circle"></i> Cannot be negative
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Error Message -->
          <div *ngIf="errorMessage" class="alert alert-danger">
            <i class="bi bi-exclamation-triangle-fill"></i>
            <span>{{ errorMessage }}</span>
          </div>

          <!-- Submit Button -->
          <div class="form-actions">
            <button 
              type="submit" 
              class="submit-btn"
              [disabled]="regForm.invalid || submitting">
              <i class="bi bi-check-circle-fill"></i>
              <span>{{ submitting ? 'Registering...' : 'Register & Get Quotes' }}</span>
            </button>
          </div>
        </form>
      </div>
    </div>

    <!-- Success Toast -->
    <div *ngIf="showSuccessToast" class="toast-notification success">
      <i class="bi bi-check-circle-fill"></i>
      <span>Vehicle Registered Successfully!</span>
    </div>
  `,
  styles: [`
    .registration-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 40px 20px;
    }

    .registration-card {
      max-width: 1000px;
      margin: 0 auto;
      background: white;
      border-radius: 25px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      overflow: hidden;
      animation: slideUp 0.6s ease;
    }

    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .card-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 40px;
      display: flex;
      align-items: center;
      gap: 25px;
    }

    .card-header i {
      font-size: 3.5rem;
    }

    .card-header h2 {
      font-size: 2rem;
      font-weight: 700;
      margin: 0 0 8px;
    }

    .card-header p {
      font-size: 1.1rem;
      opacity: 0.95;
      margin: 0;
    }

    .form-sections {
      padding: 45px;
    }

    .form-section {
      margin-bottom: 40px;
      padding: 30px;
      background: #f8f9fa;
      border-radius: 20px;
      border: 2px solid #e9ecef;
    }

    .section-header {
      display: flex;
      align-items: center;
      gap: 15px;
      margin-bottom: 30px;
      padding-bottom: 15px;
      border-bottom: 3px solid #667eea;
    }

    .section-header i {
      font-size: 2rem;
      color: #667eea;
    }

    .section-header h3 {
      font-size: 1.5rem;
      font-weight: 700;
      color: #333;
      margin: 0;
    }

    .form-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 25px;
    }

    .form-group {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .form-group label {
      font-size: 1rem;
      font-weight: 600;
      color: #555;
      display: flex;
      align-items: center;
      gap: 5px;
    }

    .form-control {
      padding: 14px 18px;
      border: 2px solid #dee2e6;
      border-radius: 12px;
      font-size: 1rem;
      transition: all 0.3s ease;
      background: white;
    }

    .form-control:focus {
      outline: none;
      border-color: #667eea;
      box-shadow: 0 0 0 4px rgba(102,126,234,0.1);
      transform: translateY(-2px);
    }

    .form-control:hover {
      border-color: #adb5bd;
    }

    .form-control.ng-invalid.ng-touched {
      border-color: #dc3545;
    }

    .form-control.ng-valid.ng-touched {
      border-color: #28a745;
    }

    .error-msg {
      color: #dc3545;
      font-size: 0.9rem;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 8px 12px;
      background: #fff5f5;
      border-radius: 8px;
      border-left: 3px solid #dc3545;
    }

    .error-msg i {
      font-size: 1.1rem;
    }

    .alert {
      padding: 18px 22px;
      border-radius: 15px;
      margin-bottom: 25px;
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 1rem;
      font-weight: 600;
      animation: shake 0.5s ease;
    }

    @keyframes shake {
      0%, 100% { transform: translateX(0); }
      25% { transform: translateX(-5px); }
      75% { transform: translateX(5px); }
    }

    .alert-danger {
      background: #fff5f5;
      color: #dc3545;
      border: 2px solid #dc3545;
    }

    .alert i {
      font-size: 1.5rem;
    }

    .form-actions {
      padding: 0 45px 45px;
    }

    .submit-btn {
      width: 100%;
      padding: 20px;
      background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
      color: white;
      border: none;
      border-radius: 50px;
      font-size: 1.2rem;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      box-shadow: 0 8px 25px rgba(76,175,80,0.4);
    }

    .submit-btn:hover:not(:disabled) {
      transform: translateY(-3px);
      box-shadow: 0 12px 35px rgba(76,175,80,0.5);
    }

    .submit-btn:disabled {
      opacity: 0.6;
      cursor: not-allowed;
      transform: none;
    }

    .submit-btn i {
      font-size: 1.5rem;
    }

    .toast-notification {
      position: fixed;
      top: 30px;
      right: 30px;
      background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
      color: white;
      padding: 20px 30px;
      border-radius: 15px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.3);
      display: flex;
      align-items: center;
      gap: 15px;
      font-size: 1.1rem;
      font-weight: 600;
      z-index: 9999;
      animation: slideInRight 0.5s ease, fadeOut 0.5s ease 2.5s;
    }

    @keyframes slideInRight {
      from {
        opacity: 0;
        transform: translateX(100px);
      }
      to {
        opacity: 1;
        transform: translateX(0);
      }
    }

    @keyframes fadeOut {
      to {
        opacity: 0;
        transform: translateX(100px);
      }
    }

    .toast-notification i {
      font-size: 1.8rem;
    }

    @media (max-width: 768px) {
      .card-header {
        flex-direction: column;
        text-align: center;
        padding: 30px 20px;
      }

      .card-header i {
        font-size: 2.5rem;
      }

      .form-sections {
        padding: 30px 20px;
      }

      .form-section {
        padding: 20px;
      }

      .form-grid {
        grid-template-columns: 1fr;
      }

      .form-actions {
        padding: 0 20px 30px;
      }

      .toast-notification {
        top: 15px;
        right: 15px;
        left: 15px;
        font-size: 1rem;
      }
    }
  `]
})
export class VehicleRegistrationComponent implements OnInit {
  // user model must exist for template binding
  user: User = {
    userId: '',
    name: '',
    email: '',
    phone: ''
  };

  vehicle: Vehicle = {
    id: undefined,
    userId: '',
    vehicleNumber: '',
    vehicleYear: new Date().getFullYear(),
    coverageType: '',
    coverageAmount: 0,
    coverageDeductibles: 0,
    noOfDrivingAccidents: 0,
    noOfDrivingViolations: 0,
    createdAt: undefined
  };

  currentYear = new Date().getFullYear();
  errorMessage: string = '';
  submitting: boolean = false;
  showSuccessToast: boolean = false;

  constructor(
    private userService: UserService,
    private vehicleService: VehicleService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      if (params['userId']) {
        this.vehicle.userId = String(params['userId']);
      }
      if (params['vehicleNumber']) {
        this.vehicle.vehicleNumber = params['vehicleNumber'];
      }
    });
  }

  submitRegistration(): void {
    this.errorMessage = '';
    this.submitting = true;

    if (!this.user.name || this.user.name.trim().length < 2) {
      this.errorMessage = 'Name must be at least 2 characters';
      this.submitting = false;
      return;
    }
    if (!this.user.email || !this.isValidEmail(this.user.email)) {
      this.errorMessage = 'Please enter a valid email address';
      this.submitting = false;
      return;
    }
    if (!this.user.phone || !this.isValidPhone(this.user.phone)) {
      this.errorMessage = 'Please enter a valid 10-digit phone number';
      this.submitting = false;
      return;
    }

    // Save user first
    this.userService.saveUser(this.user).subscribe({
      next: (savedUser) => {
        // Store userId as string
        const userIdString = String(savedUser.userId);
        this.vehicle.userId = userIdString;

        // Save vehicle
        this.vehicleService.saveVehicle(this.vehicle).subscribe({
          next: (response: any) => {
            this.submitting = false;
            this.showSuccessToast = true;

            console.log('✅ Vehicle registration response:', response);
            
            // Extract vehicle ID from response (backend now returns it)
            const vehicleId = response.id;
            const vehicleNum = response.vehicleNumber || this.vehicle.vehicleNumber;
            
            console.log('✅ Vehicle ID:', vehicleId, 'Vehicle Number:', vehicleNum);

            // Navigate directly with the vehicle ID from registration response
            setTimeout(() => {
              this.showSuccessToast = false;
              
              if (vehicleId) {
                // Navigate with vehicle ID
                this.router.navigate(['/quotes'], {
                  queryParams: {
                    vehicleId: vehicleId,
                    vehicleNumber: vehicleNum,
                    userId: userIdString
                  }
                });
              } else {
                // Fallback: wait briefly and fetch vehicle to get ID
                console.log('⚠️ No vehicle ID in response, fetching...');
                setTimeout(() => {
                  this.vehicleService.getVehicleByNumber(vehicleNum).subscribe({
                    next: (completeVehicle) => {
                      console.log('✅ Fetched vehicle with ID:', completeVehicle.id);
                      this.router.navigate(['/quotes'], {
                        queryParams: {
                          vehicleId: completeVehicle.id,
                          vehicleNumber: vehicleNum,
                          userId: userIdString
                        }
                      });
                    },
                    error: (err) => {
                      console.error('❌ Cannot fetch vehicle, navigating anyway:', err);
                      this.router.navigate(['/quotes'], {
                        queryParams: {
                          vehicleNumber: vehicleNum,
                          userId: userIdString
                        }
                      });
                    }
                  });
                }, 500);
              }
            }, 1200);
          },
          error: (err) => {
            this.submitting = false;
            this.errorMessage = this.getErrorMessage(err);
            console.error('❌ Vehicle save error:', err);
          }
        });
      },
      error: (err) => {
        this.submitting = false;
        this.errorMessage = this.getErrorMessage(err);
        console.error('❌ User save error:', err);
      }
    });
  }

  isValidEmail(email: string): boolean {
    const emailRegex = /^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
  }

  isValidPhone(phone: string): boolean {
    const phoneRegex = /^[6-9][0-9]{9}$/;
    return phoneRegex.test(phone);
  }

  getErrorMessage(error: any): string {
    if (!error) return 'An error occurred. Please try again.';
    if (error.error) {
      if (typeof error.error === 'string') return error.error;
      if (error.error.message) return error.error.message;
    }
    if (error.message) return error.message;
    if (error.status === 400) return 'Invalid data. Please check all fields and try again.';
    return 'An error occurred. Please try again.';
  }
}
// ...existing code...