package com.bikeinsurance.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "kyc")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class KYC {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @OneToOne
    @JoinColumn(name = "insurance_quote_id", nullable = false)
    private InsuranceQuote insuranceQuote;
    
    @Column(nullable = false)
    private String drivingLicensePath;
    
    @Column(nullable = false)
    private String rcPath;
    
    @Column(nullable = false)
    private String aadharPath;
    
    @Column(nullable = false)
    private String verificationStatus;
    
    @Column(nullable = false, updatable = false)
    private LocalDateTime uploadedAt = LocalDateTime.now();
}
