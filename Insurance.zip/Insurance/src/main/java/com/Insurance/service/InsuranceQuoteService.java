package com.Insurance.service;

import com.Insurance.model.InsuranceQuote;
import com.Insurance.model.User;
import com.Insurance.model.Vehicle;
import com.Insurance.repository.InsuranceQuoteRepository;
import com.Insurance.repository.UserRepository;
import com.Insurance.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InsuranceQuoteService {

    @Autowired
    private InsuranceQuoteRepository insuranceQuoteRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private VehicleRepository vehicleRepository;

    public InsuranceQuote saveInsuranceQuote(InsuranceQuote insuranceQuote) {

        // Validate User
        Long userId = insuranceQuote.getUser().getId();
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Validate Vehicle
        String vehicleNumber = insuranceQuote.getVehicle().getVehicleNumber();
        Vehicle vehicle = vehicleRepository.findById(vehicleNumber)
                .orElseThrow(() -> new RuntimeException("Vehicle not found"));

        // Attach objects
        insuranceQuote.setUser(user);
        insuranceQuote.setVehicle(vehicle);

        return insuranceQuoteRepository.save(insuranceQuote);
    }

    public InsuranceQuote generateQuote(InsuranceQuote insuranceQuote) {

        // Premium formula
        insuranceQuote.setPremiumAmount(
                insuranceQuote.getCoverageAmount() * 0.05
        );

        insuranceQuote.setQuoteDetails("Generated premium based on coverage amount.");

        return saveInsuranceQuote(insuranceQuote);
    }

    public List<InsuranceQuote> getAllInsuranceQuotes() {
        return insuranceQuoteRepository.findAll();
    }

    public InsuranceQuote getInsuranceQuoteById(Long id) {
        return insuranceQuoteRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Quote not found"));
    }

    public void deleteInsuranceQuote(Long id) {
        insuranceQuoteRepository.deleteById(id);
    }

    public InsuranceQuote updateInsuranceQuote(InsuranceQuote insuranceQuote) {
        InsuranceQuote existing = insuranceQuoteRepository.findById(insuranceQuote.getQuoteId())
                .orElseThrow(() -> new RuntimeException("Quote not found"));

        existing.setCoverageType(insuranceQuote.getCoverageType());
        existing.setCoverageAmount(insuranceQuote.getCoverageAmount());
        existing.setCoverageDeductibles(insuranceQuote.getCoverageDeductibles());
        existing.setPremiumAmount(insuranceQuote.getPremiumAmount());
        existing.setQuoteDetails(insuranceQuote.getQuoteDetails());

        return insuranceQuoteRepository.save(existing);
    }
}
