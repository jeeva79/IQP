package com.bikeinsurance.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.bikeinsurance.model.KYC;
import com.bikeinsurance.model.InsuranceQuote;

@Repository
public interface KYCRepository extends JpaRepository<KYC, Long> {
    KYC findByInsuranceQuote(InsuranceQuote insuranceQuote);
}
