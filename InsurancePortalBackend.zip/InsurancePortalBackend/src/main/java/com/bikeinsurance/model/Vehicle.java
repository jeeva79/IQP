package com.bikeinsurance.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "vehicles")
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Store user's UUID string
    @Column(name = "user_id", nullable = false)
    private String userId;

    // Link to User entity, read-only
    @OneToOne
    @JoinColumn(name = "user_id", referencedColumnName = "userId", insertable = false, updatable = false)
    private User user;

    @Column(nullable = false, unique = true)
    private String vehicleNumber;

    @Column(nullable = false)
    private Integer vehicleYear;

    @Column(nullable = false)
    private Integer noOfDrivingAccidents;

    @Column(nullable = false)
    private Integer noOfDrivingViolations;

    @Column(nullable = false)
    private String coverageType;

    @Column(nullable = false)
    private Double coverageAmount;

    @Column(nullable = false)
    private Double coverageDeductibles;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public Vehicle() {}

    // All Getters and Setters
    public Long getId() { return id; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public User getUser() { return user; }
    public void setUser(User user) { this.user = user; }

    public String getVehicleNumber() { return vehicleNumber; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }

    public Integer getVehicleYear() { return vehicleYear; }
    public void setVehicleYear(Integer vehicleYear) { this.vehicleYear = vehicleYear; }

    public Integer getNoOfDrivingAccidents() { return noOfDrivingAccidents; }
    public void setNoOfDrivingAccidents(Integer noOfDrivingAccidents) { this.noOfDrivingAccidents = noOfDrivingAccidents; }

    public Integer getNoOfDrivingViolations() { return noOfDrivingViolations; }
    public void setNoOfDrivingViolations(Integer noOfDrivingViolations) { this.noOfDrivingViolations = noOfDrivingViolations; }

    public String getCoverageType() { return coverageType; }
    public void setCoverageType(String coverageType) { this.coverageType = coverageType; }

    public Double getCoverageAmount() { return coverageAmount; }
    public void setCoverageAmount(Double coverageAmount) { this.coverageAmount = coverageAmount; }

    public Double getCoverageDeductibles() { return coverageDeductibles; }
    public void setCoverageDeductibles(Double coverageDeductibles) { this.coverageDeductibles = coverageDeductibles; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}
