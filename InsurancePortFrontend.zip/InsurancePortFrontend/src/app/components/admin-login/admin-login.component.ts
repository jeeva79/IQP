import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-admin-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container mt-5">
      <div class="card mx-auto" style="max-width: 500px;">
        <div class="card-header bg-danger text-white">
          <h3 class="mb-0">Admin Login</h3>
        </div>
        <div class="card-body">
          <form (ngSubmit)="login()">
            <div class="mb-3">
              <label class="form-label">Admin ID</label>
              <input 
                type="text" 
                [(ngModel)]="adminId" 
                name="adminId"
                class="form-control" 
                placeholder="Enter Admin ID"
                required>
            </div>
            <div class="mb-3">
              <label class="form-label">Password</label>
              <input 
                type="password" 
                [(ngModel)]="password" 
                name="password"
                class="form-control" 
                placeholder="Enter Password"
                required>
            </div>
            <div *ngIf="errorMessage" class="alert alert-danger">
              {{ errorMessage }}
            </div>
            <button type="submit" class="btn btn-danger w-100">Login</button>
            <button 
              type="button" 
              class="btn btn-secondary w-100 mt-2"
              (click)="goBack()">
              Back
            </button>
          </form>
        </div>
      </div>
    </div>
  `
})
export class AdminLoginComponent {
  adminId: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  login(): void {
    this.errorMessage = '';
    const isValid = this.authService.login('admin', this.adminId, this.password);
    
    if (isValid) {
      this.router.navigate(['/admin-applications']);
    } else {
      this.errorMessage = 'Invalid Admin ID or Password!';
    }
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}