export interface Vehicle {
  id?: number;
  userId: string;
  vehicleNumber: string;
  vehicleYear: number;
  noOfDrivingAccidents: number;
  noOfDrivingViolations: number;
  coverageType: string;
  coverageAmount: number;
  coverageDeductibles: number;
}