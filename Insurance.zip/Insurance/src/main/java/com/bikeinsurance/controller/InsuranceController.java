package com.bikeinsurance.controller;

import com.bikeinsurance.model.InsuranceQuote;
import com.bikeinsurance.dto.InsuranceApplicationDTO;
import com.bikeinsurance.dto.InsuranceQuoteResponseDTO;
import com.bikeinsurance.service.InsuranceQuoteService;
import com.bikeinsurance.service.VehicleService;
import com.bikeinsurance.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/insurance")
@CrossOrigin(origins = "*")
public class InsuranceController {
    @Autowired
    private InsuranceQuoteService quoteService;
    @Autowired
    private VehicleService vehicleService;
    @Autowired
    private UserService userService;
    
    @GetMapping("/calculate/{vehicleId}")
    public ResponseEntity<Map<String, Object>> calculateQuotes(@PathVariable Long vehicleId) {
        try {
            List<InsuranceQuoteResponseDTO> quotes = quoteService.getQuotes(vehicleId, vehicleService);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("quotes", quotes);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                Map.of("success", false, "message", e.getMessage())
            );
        }
    }
    
    @PostMapping("/select-provider")
    public ResponseEntity<Map<String, Object>> selectProvider(@RequestBody InsuranceApplicationDTO appDTO) {
        try {
            InsuranceQuote quote = quoteService.saveQuote(
                appDTO.getUserId(), appDTO.getVehicleId(), 
                appDTO.getSelectedProvider(), appDTO.getSelectedPlan(), 
                appDTO.getPremiumAmount(), userService, vehicleService
            );
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("quoteId", quote.getId());
            response.put("message", "Provider selected successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                Map.of("success", false, "message", e.getMessage())
            );
        }
    }
}
