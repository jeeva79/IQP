package com.Insurance.controller;

import com.Insurance.model.InsuranceQuote;
import com.Insurance.service.InsuranceQuoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/insurance-quotes")
public class InsuranceQuoteController {

    @Autowired
    private InsuranceQuoteService insuranceQuoteService;

    @GetMapping
    public List<InsuranceQuote> getAllInsuranceQuotes() {
        return insuranceQuoteService.getAllInsuranceQuotes();
    }

    @GetMapping("/{id}")
    public ResponseEntity<InsuranceQuote> getInsuranceQuoteById(@PathVariable Long id) {
        InsuranceQuote quote = insuranceQuoteService.getInsuranceQuoteById(id);
        return ResponseEntity.ok(quote);
    }



    @PostMapping
    public InsuranceQuote createInsuranceQuote(@RequestBody InsuranceQuote insuranceQuote) {
        return insuranceQuoteService.saveInsuranceQuote(insuranceQuote);
    }

    @PostMapping("/quote")
    public InsuranceQuote generateQuote(@RequestBody InsuranceQuote insuranceQuote) {
        return insuranceQuoteService.generateQuote(insuranceQuote);
    }

    @PostMapping("/store")
    public InsuranceQuote storeQuote(@RequestBody InsuranceQuote insuranceQuote) {
        return insuranceQuoteService.saveInsuranceQuote(insuranceQuote);
    }

    @PutMapping("/requote")
    public InsuranceQuote updateQuote(@RequestBody InsuranceQuote insuranceQuote) {
        return insuranceQuoteService.updateInsuranceQuote(insuranceQuote);
    }

    @GetMapping("/history")
    public List<InsuranceQuote> getQuoteHistory() {
        return insuranceQuoteService.getAllInsuranceQuotes();
    }
}