package com.Insurance.repository;

import com.Insurance.model.InsuranceQuote;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InsuranceQuoteRepository extends JpaRepository<InsuranceQuote, Long> {
    // Additional query methods can be defined here
}