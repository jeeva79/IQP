package com.bikeinsurance.util;

import java.util.regex.Pattern;

public class ValidationUtils {

    private static final Pattern EMAIL_PATTERN = 
        Pattern.compile("^[A-Za-z0-9+_.-]+@(.+)$");
    
    private static final Pattern PHONE_PATTERN = 
        Pattern.compile("^[6-9]\\d{9}$");
    
    private static final Pattern VEHICLE_NUMBER_PATTERN = 
        Pattern.compile("^[A-Z]{2}\\d{2}[A-Z]{1,2}\\d{4}$");

    public static void validateEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            throw new IllegalArgumentException("Email is required");
        }
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            throw new IllegalArgumentException("Invalid email format");
        }
    }

    public static void validatePhone(String phone) {
        if (phone == null || phone.trim().isEmpty()) {
            throw new IllegalArgumentException("Phone number is required");
        }
        if (!PHONE_PATTERN.matcher(phone).matches()) {
            throw new IllegalArgumentException("Invalid phone number. Must be 10 digits starting with 6-9");
        }
    }

    public static void validateVehicleNumber(String vehicleNumber) {
        if (vehicleNumber == null || vehicleNumber.trim().isEmpty()) {
            throw new IllegalArgumentException("Vehicle number is required");
        }
        if (!VEHICLE_NUMBER_PATTERN.matcher(vehicleNumber).matches()) {
            throw new IllegalArgumentException("Invalid vehicle number format. Expected format: KA01AB1234");
        }
    }

    public static void validateVehicleYear(Integer year) {
        if (year == null) {
            throw new IllegalArgumentException("Vehicle year is required");
        }
        int currentYear = java.time.Year.now().getValue();
        if (year < 1900 || year > currentYear) {
            throw new IllegalArgumentException("Invalid vehicle year. Must be between 1900 and " + currentYear);
        }
    }

    public static void validateName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name is required");
        }
        if (name.length() < 2 || name.length() > 100) {
            throw new IllegalArgumentException("Name must be between 2 and 100 characters");
        }
    }

    public static void validateNonNegativeInteger(Integer value, String fieldName) {
        if (value == null) {
            throw new IllegalArgumentException(fieldName + " is required");
        }
        if (value < 0) {
            throw new IllegalArgumentException(fieldName + " cannot be negative");
        }
    }

    public static void validatePositiveDouble(Double value, String fieldName) {
        if (value == null) {
            throw new IllegalArgumentException(fieldName + " is required");
        }
        if (value <= 0) {
            throw new IllegalArgumentException(fieldName + " must be greater than 0");
        }
    }

    public static void validateCoverageType(String coverageType) {
        if (coverageType == null || coverageType.trim().isEmpty()) {
            throw new IllegalArgumentException("Coverage type is required");
        }
        if (!coverageType.equalsIgnoreCase("Comprehensive") && 
            !coverageType.equalsIgnoreCase("Third Party")) {
            throw new IllegalArgumentException("Coverage type must be either 'Comprehensive' or 'Third Party'");
        }
    }
}