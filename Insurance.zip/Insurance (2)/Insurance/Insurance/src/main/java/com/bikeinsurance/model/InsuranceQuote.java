package com.bikeinsurance.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "insurance_quotes")
public class InsuranceQuote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "vehicle_user_id", referencedColumnName = "userId")
    private Vehicle vehicle;
    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "userId", nullable = false)
    private User user;


    @Column(nullable = false)
    private String selectedProvider;

    @Column(nullable = false)
    private String selectedPlan;

    @Column(nullable = false)
    private Double premiumAmount;

    @Column(nullable = false)
    private String status;

    @Column(nullable = false, updatable = false)
    private LocalDateTime appliedAt = LocalDateTime.now();

    @OneToOne(mappedBy = "insuranceQuote", cascade = CascadeType.ALL)
    private KYC kyc;

    // -------------- GETTERS -------------------

    public Long getId() { return id; }

    public User getUser() { return user; }

    public Vehicle getVehicle() { return vehicle; }

    public String getSelectedProvider() { return selectedProvider; }

    public String getSelectedPlan() { return selectedPlan; }

    public Double getPremiumAmount() { return premiumAmount; }

    public String getStatus() { return status; }

    public LocalDateTime getAppliedAt() { return appliedAt; }

    public KYC getKyc() { return kyc; }

    // -------------- SETTERS -------------------

    public void setUser(User user) { this.user = user; }

    public void setVehicle(Vehicle vehicle) { this.vehicle = vehicle; }

    public void setSelectedProvider(String selectedProvider) { this.selectedProvider = selectedProvider; }

    public void setSelectedPlan(String selectedPlan) { this.selectedPlan = selectedPlan; }

    public void setPremiumAmount(Double premiumAmount) { this.premiumAmount = premiumAmount; }

    public void setStatus(String status) { this.status = status; }

    public void setKyc(KYC kyc) { this.kyc = kyc; }
}
