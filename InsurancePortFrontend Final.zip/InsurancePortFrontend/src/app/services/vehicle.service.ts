import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Vehicle } from '../models/vehicle.model';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {
  private apiUrl = 'http://localhost:8080/api/vehicle';

  constructor(private http: HttpClient) {}

  saveVehicle(vehicle: Vehicle): Observable<Vehicle> {
    return this.http.post<any>(`${this.apiUrl}/register`, vehicle)
      .pipe(
        map(response => {
          console.log('✅ Backend Response:', response);
          
          if (response.success) {
            // Return complete vehicle object including the ID from backend
            return {
              ...vehicle,
              id: response.id, // ADD ID FROM RESPONSE
              userId: String(response.userId),
              vehicleNumber: response.vehicleNumber || vehicle.vehicleNumber
            } as Vehicle;
          }
          throw new Error(response.message || 'Registration failed');
        }),
        catchError(error => {
          console.error('❌ Registration Error:', error);
          return throwError(() => new Error(error.error?.message || 'Failed to register vehicle'));
        })
      );
  }

  getVehicleByNumber(vehicleNumber: string): Observable<Vehicle> {
    return this.http.get<any>(`${this.apiUrl}/show/${vehicleNumber}`)
      .pipe(
        map(response => {
          console.log('✅ Get Vehicle Response:', response);
          
          if (response.success) {
            // Map all fields from backend response - userId is string
            return {
              id: response.id,
              userId: String(response.userId),
              vehicleNumber: response.vehicleNumber,
              vehicleYear: response.vehicleYear,
              noOfDrivingAccidents: response.noOfDrivingAccidents,
              noOfDrivingViolations: response.noOfDrivingViolations,
              coverageType: response.coverageType,
              coverageAmount: response.coverageAmount,
              coverageDeductibles: response.coverageDeductibles
            } as Vehicle;
          }
          throw new Error('Vehicle not found');
        }),
        catchError(error => {
          console.error('❌ Fetch Error:', error);
          return throwError(() => new Error('Vehicle not found'));
        })
      );
  }

  updateVehicle(vehicleNumber: string, vehicle: Vehicle): Observable<Vehicle> {
    return this.http.put<any>(`${this.apiUrl}/update/${vehicleNumber}`, vehicle)
      .pipe(
        map(response => {
          if (response.success) {
            return { ...vehicle, vehicleNumber: response.vehicleNumber, userId: response.userId } as Vehicle;
          }
          throw new Error(response.message || 'Update failed');
        }),
        catchError(error => {
          console.error('❌ Update Error:', error);
          return throwError(() => new Error(error.error?.message || 'Failed to update vehicle'));
        })
      );
  }
}