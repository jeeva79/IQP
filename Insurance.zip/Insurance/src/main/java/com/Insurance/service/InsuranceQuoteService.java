package com.Insurance.service;

import com.Insurance.model.InsuranceQuote;
import com.Insurance.model.User;
import com.Insurance.model.Vehicle;
import com.Insurance.repository.InsuranceQuoteRepository;
import com.Insurance.repository.UserRepository;
import com.Insurance.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InsuranceQuoteService {

    @Autowired
    private InsuranceQuoteRepository insuranceQuoteRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private VehicleRepository vehicleRepository;

    // Save or generate quote with premium
    public InsuranceQuote saveInsuranceQuote(InsuranceQuote quote) {
        Long userId = quote.getUser().getId();
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        String vehicleNumber = quote.getVehicle().getVehicleNumber();
        Vehicle vehicle = vehicleRepository.findById(vehicleNumber)
                .orElseThrow(() -> new RuntimeException("Vehicle not found"));

        quote.setUser(user);
        quote.setVehicle(vehicle);

        double premium = calculateVehiclePremium(vehicle, quote);
        quote.setPremiumAmount(premium);
        quote.setQuoteDetails("Calculated premium using vehicle & addon rules.");

        return insuranceQuoteRepository.save(quote);
    }

    // Generate quote
    public InsuranceQuote generateQuote(InsuranceQuote quote) {
        double premium = calculateVehiclePremium(quote.getVehicle(), quote);
        quote.setPremiumAmount(premium);
        quote.setQuoteDetails("Generated premium based on coverage amount.");
        return saveInsuranceQuote(quote);
    }

    public List<InsuranceQuote> getAllInsuranceQuotes() {
        return insuranceQuoteRepository.findAll();
    }

    public InsuranceQuote updateInsuranceQuote(InsuranceQuote quote) {
        InsuranceQuote existing = insuranceQuoteRepository.findById(quote.getQuoteId())
                .orElseThrow(() -> new RuntimeException("Quote not found"));

        existing.setCoverageType(quote.getCoverageType());
        existing.setCoverageAmount(quote.getCoverageAmount());
        existing.setCoverageDeductibles(quote.getCoverageDeductibles());
        existing.setEngineProtection(quote.getEngineProtection());
        existing.setNcbPercentage(quote.getNcbPercentage());
        existing.setPassengerCount(quote.getPassengerCount());
        existing.setRoadsideAssistance(quote.getRoadsideAssistance());
        existing.setZeroDepreciation(quote.getZeroDepreciation());

        double premium = calculateVehiclePremium(existing.getVehicle(), quote);
        existing.setPremiumAmount(premium);
        existing.setQuoteDetails(quote.getQuoteDetails());

        return insuranceQuoteRepository.save(existing);
    }

    // Premium calculation
    private double calculateVehiclePremium(Vehicle vehicle, InsuranceQuote quote) {
        double basePremium = vehicle.getVehicleValue() * 0.02;
        if (basePremium <= 0) basePremium = 1000;

        double addons = 0;
        if (Boolean.TRUE.equals(quote.getZeroDepreciation())) addons += basePremium * 0.15;
        if (Boolean.TRUE.equals(quote.getEngineProtection())) addons += basePremium * 0.05;
        if (Boolean.TRUE.equals(quote.getRoadsideAssistance())) addons += basePremium * 0.02;
        if (quote.getPassengerCount() != null) addons += quote.getPassengerCount() * 150;

        double deductibleDiscount = quote.getCoverageDeductibles() != null ? quote.getCoverageDeductibles() * 0.01 : 0;

        double fuelFactor = 0;
        if (vehicle.getFuelType() != null) {
            switch (vehicle.getFuelType().toLowerCase()) {
                case "diesel": fuelFactor = basePremium * 0.10; break;
                case "electric": fuelFactor = -basePremium * 0.20; break;
                case "cng": fuelFactor = basePremium * 0.05; break;
            }
        }

        int age = 2025 - vehicle.getVehicleYear();
        double ageCharge = 0;
        if (age < 3) ageCharge = basePremium * 0.05;
        else if (age > 5) ageCharge = -basePremium * 0.10;

        double ncbDiscount = quote.getNcbPercentage() != null ? basePremium * quote.getNcbPercentage() / 100.0 : 0;

        return Math.max(basePremium + addons + fuelFactor + ageCharge - deductibleDiscount - ncbDiscount, 1000);
    }
}
