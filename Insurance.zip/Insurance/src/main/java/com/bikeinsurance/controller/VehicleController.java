package com.bikeinsurance.controller;

import com.bikeinsurance.model.Vehicle;
import com.bikeinsurance.dto.VehicleDTO;
import com.bikeinsurance.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/vehicle")
@CrossOrigin(origins = "*")
public class VehicleController {
    @Autowired
    private VehicleService vehicleService;
    
    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> registerVehicle(@RequestBody VehicleDTO vehicleDTO) {
        try {
            Vehicle vehicle = vehicleService.saveVehicle(vehicleDTO);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("vehicleId", vehicle.getId());
            response.put("message", "Vehicle registered successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                Map.of("success", false, "message", e.getMessage())
            );
        }
    }
}
