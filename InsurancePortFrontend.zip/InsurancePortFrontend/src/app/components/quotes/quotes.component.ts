import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { InsuranceService } from '../../services/insurance.service';
import { VehicleService } from '../../services/vehicle.service';
import { InsuranceQuote, InsuranceApplication } from '../../models/insurance-quote.model';

@Component({
  selector: 'app-quotes',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container mt-5">
      <h2 class="mb-4">Insurance Quotes</h2>

      <div *ngIf="loading" class="text-center">
        <div class="spinner-border" role="status">
          <span class="visually-hidden">Loading quotes...</span>
        </div>
        <p class="mt-2">Calculating insurance quotes...</p>
      </div>

      <div *ngIf="errorMessage" class="alert alert-danger">
        {{ errorMessage }}
      </div>

      <div *ngIf="!loading && quotes.length === 0 && !errorMessage" class="alert alert-info">
        No quotes available for this vehicle.
      </div>

      <div *ngIf="!loading && quotes.length > 0" class="row">
        <div *ngFor="let quote of quotes" class="col-md-6 mb-4">
          <div class="card h-100 border-primary">
            <div class="card-header bg-primary text-white">
              <h4 class="mb-0">{{ quote.providerName }}</h4>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-6">
                  <h5 class="text-muted">Basic Plan</h5>
                  <h3 class="text-success">₹{{ quote.basic | number:'1.2-2' }}</h3>
                  <button 
                    class="btn btn-outline-success w-100 mt-2"
                    (click)="selectQuote(quote, 'Basic')">
                    Select Basic
                  </button>
                </div>
                <div class="col-6">
                  <h5 class="text-muted">Premium Plan</h5>
                  <h3 class="text-primary">₹{{ quote.premium | number:'1.2-2' }}</h3>
                  <button 
                    class="btn btn-primary w-100 mt-2"
                    (click)="selectQuote(quote, 'Premium')">
                    Select Premium
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div *ngIf="selectedQuote" class="mt-4">
        <div class="alert alert-info">
          <strong>Selected:</strong> {{ selectedQuote.providerName }} - {{ selectedPlan }} Plan 
          (₹{{ selectedPlan === 'Basic' ? selectedQuote.basic : selectedQuote.premium | number:'1.2-2' }})
        </div>
      </div>
    </div>
  `
})
export class QuotesComponent implements OnInit {
  quotes: InsuranceQuote[] = [];
  vehicleNumber: string = '';
  userId: string = '';
  vehicleId: number = 0;
  selectedQuote: InsuranceQuote | null = null;
  selectedPlan: string = '';
  errorMessage: string = '';
  loading: boolean = false;

  constructor(
    private insuranceService: InsuranceService,
    private vehicleService: VehicleService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.vehicleNumber = params['vehicleNumber'];
      this.userId = params['userId'];
      
      if (this.vehicleNumber) {
        this.loadQuotes();
      } else {
        this.errorMessage = 'Vehicle information is missing.';
      }
    });
  }

  loadQuotes(): void {
    this.loading = true;
    this.errorMessage = '';

    // First get vehicle to obtain its ID
    this.vehicleService.getVehicleByNumber(this.vehicleNumber).subscribe({
      next: (vehicle) => {
        if (vehicle.id) {
          this.vehicleId = vehicle.id;
          // Now fetch quotes using vehicle ID
          this.insuranceService.getQuotes(vehicle.id).subscribe({
            next: (data) => {
              this.quotes = data;
              this.loading = false;
            },
            error: (err) => {
              console.error('Error fetching quotes:', err);
              this.errorMessage = 'Failed to fetch insurance quotes. Please try again.';
              this.loading = false;
            }
          });
        } else {
          this.errorMessage = 'Vehicle ID not found.';
          this.loading = false;
        }
      },
      error: (err) => {
        console.error('Error fetching vehicle:', err);
        this.errorMessage = 'Failed to fetch vehicle details.';
        this.loading = false;
      }
    });
  }

  selectQuote(quote: InsuranceQuote, plan: string): void {
    this.selectedQuote = quote;
    this.selectedPlan = plan;

    const premiumAmount = plan === 'Basic' ? quote.basic : quote.premium;

    const application: InsuranceApplication = {
      userId: this.userId,
      vehicleId: this.vehicleId,
      selectedProvider: quote.providerName,
      selectedPlan: plan,
      premiumAmount: premiumAmount
    };

    this.insuranceService.selectProvider(application).subscribe({
      next: (quoteId) => {
        // Navigate to KYC upload with quote ID
        this.router.navigate(['/kyc-upload'], {
          queryParams: {
            quoteId: quoteId,
            vehicleNumber: this.vehicleNumber,
            provider: quote.providerName
          }
        });
      },
      error: (err) => {
        console.error('Error selecting provider:', err);
        this.errorMessage = 'Failed to select insurance provider. Please try again.';
      }
    });
  }
}