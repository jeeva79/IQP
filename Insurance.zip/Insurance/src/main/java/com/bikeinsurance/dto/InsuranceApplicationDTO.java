package com.bikeinsurance.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InsuranceApplicationDTO {
    private Long userId;
    private Long vehicleId;
    private String selectedProvider;
    private String selectedPlan;
    private Double premiumAmount;
}
