import { Routes } from '@angular/router';
import { RoleSelectionComponent } from './components/role-selection/role-selection.component';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { AdminApplicationsComponent } from './components/admin-applications/admin-applications.component';
import { VehicleCheckComponent } from './components/vehicle-check/vehicle-check.component';
import { UserFormComponent } from './components/user-form/user-form.component';
import { VehicleFormComponent } from './components/vehicle-form/vehicle-form.component';
import { QuotesComponent } from './components/quotes/quotes.component';
import { KycUploadComponent } from './components/kyc-upload/kyc-upload.component';
import { AdminGuard } from './guards/admin.guard';

export const routes: Routes = [
  { path: '', component: RoleSelectionComponent },
  { path: 'admin-login', component: AdminLoginComponent },
  { 
    path: 'admin-applications', 
    component: AdminApplicationsComponent,
    canActivate: [AdminGuard]
  },
  { path: 'vehicle-check', component: VehicleCheckComponent },
  { path: 'user-form', component: UserFormComponent },
  { path: 'vehicle-form', component: VehicleFormComponent },
  { path: 'quotes', component: QuotesComponent },
  { path: 'kyc-upload', component: KycUploadComponent },
  { path: '**', redirectTo: '', pathMatch: 'full' }
];
