package com.bikeinsurance.controller;

import com.bikeinsurance.model.KYC;
import com.bikeinsurance.service.KYCService;
import com.bikeinsurance.service.InsuranceQuoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/kyc")
@CrossOrigin(origins = "*")
public class KYCController {
    @Autowired
    private KYCService kycService;
    @Autowired
    private InsuranceQuoteService quoteService;
    
    @PostMapping("/upload/{quoteId}")
    public ResponseEntity<Map<String, Object>> uploadKYC(
            @PathVariable Long quoteId,
            @RequestParam("drivingLicense") MultipartFile drivingLicense,
            @RequestParam("rc") MultipartFile rc,
            @RequestParam("aadhar") MultipartFile aadhar) {
        try {
            KYC kyc = kycService.uploadKYC(quoteId, drivingLicense, rc, aadhar, quoteService);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("kycId", kyc.getId());
            response.put("message", "KYC uploaded successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                Map.of("success", false, "message", e.getMessage())
            );
        }
    }
}
