package com.bikeinsurance.dto;

public class AdminApplicationViewDTO {

    private Long id;
    private String userName;
    private String userEmail;
    private String vehicleNumber;
    private String selectedProvider;
    private String selectedPlan;
    private Double premiumAmount;
    private String kycStatus;
    private String appliedAt;

    public AdminApplicationViewDTO(
            Long id,
            String userName,
            String userEmail,
            String vehicleNumber,
            String selectedProvider,
            String selectedPlan,
            Double premiumAmount,
            String kycStatus,
            String appliedAt
    ) {
        this.id = id;
        this.userName = userName;
        this.userEmail = userEmail;
        this.vehicleNumber = vehicleNumber;
        this.selectedProvider = selectedProvider;
        this.selectedPlan = selectedPlan;
        this.premiumAmount = premiumAmount;
        this.kycStatus = kycStatus;
        this.appliedAt = appliedAt;
    }

    // ----------- GETTERS --------------

    public Long getId() { return id; }
    public String getUserName() { return userName; }
    public String getUserEmail() { return userEmail; }
    public String getVehicleNumber() { return vehicleNumber; }
    public String getSelectedProvider() { return selectedProvider; }
    public String getSelectedPlan() { return selectedPlan; }
    public Double getPremiumAmount() { return premiumAmount; }
    public String getKycStatus() { return kycStatus; }
    public String getAppliedAt() { return appliedAt; }

    // ----------- SETTERS --------------

    public void setId(Long id) { this.id = id; }
    public void setUserName(String userName) { this.userName = userName; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }
    public void setVehicleNumber(String vehicleNumber) { this.vehicleNumber = vehicleNumber; }
    public void setSelectedProvider(String selectedProvider) { this.selectedProvider = selectedProvider; }
    public void setSelectedPlan(String selectedPlan) { this.selectedPlan = selectedPlan; }
    public void setPremiumAmount(Double premiumAmount) { this.premiumAmount = premiumAmount; }
    public void setKycStatus(String kycStatus) { this.kycStatus = kycStatus; }
    public void setAppliedAt(String appliedAt) { this.appliedAt = appliedAt; }
}
