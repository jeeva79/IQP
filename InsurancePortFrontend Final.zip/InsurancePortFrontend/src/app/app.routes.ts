import { Routes } from '@angular/router';
import { LandingComponent } from './components/landing/landing.component';
import { AdminLoginComponent } from './components/admin-login/admin-login.component';
import { AdminApplicationsComponent } from './components/admin-applications/admin-applications.component';
import { VehicleCheckComponent } from './components/vehicle-check/vehicle-check.component';
import { VehicleDetailsComponent } from './components/vehicle-details/vehicle-details.component';
import { VehicleRegistrationComponent } from './components/vehicle-registration/vehicle-registration.component';
import { VehicleFormComponent } from './components/vehicle-form/vehicle-form.component';
import { QuotesComponent } from './components/quotes/quotes.component';
import { InsuranceDetailsComponent } from './components/insurance-details/insurance-details.component';
import { KycUploadComponent } from './components/kyc-upload/kyc-upload.component';
import { ApplicationSuccessComponent } from './components/application-success/application-success.component';
import { AdminGuard } from './guards/admin.guard';

export const routes: Routes = [
  { path: '', component: LandingComponent },
  { path: 'admin-login', component: AdminLoginComponent },
  { 
    path: 'admin-applications', 
    component: AdminApplicationsComponent,
    canActivate: [AdminGuard]
  },
  { path: 'vehicle-check', component: VehicleCheckComponent },
  { path: 'vehicle-details', component: VehicleDetailsComponent },
  { path: 'vehicle-registration', component: VehicleRegistrationComponent },
  { path: 'vehicle-form', component: VehicleFormComponent },
  { path: 'quotes', component: QuotesComponent },
  { path: 'insurance-details', component: InsuranceDetailsComponent },
  { path: 'kyc-upload', component: KycUploadComponent },
  { path: 'application-success', component: ApplicationSuccessComponent },
  { path: '**', redirectTo: '', pathMatch: 'full' }
];