package com.bikeinsurance.service;

import com.bikeinsurance.model.Vehicle;
import com.bikeinsurance.dto.InsuranceQuoteResponseDTO;
import org.springframework.stereotype.Service;

@Service
public class InsuranceCalculatorService {
    public InsuranceQuoteResponseDTO calculatePolicyBazaar(Vehicle vehicle, String plan) {
        double baseAmount = 2000;
        double accidentFactor = vehicle.getNoOfDrivingAccidents() * 300;
        double violationFactor = vehicle.getNoOfDrivingViolations() * 200;
        double yearFactor = (2025 - vehicle.getVehicleYear()) * 100;
        double basicPremium = baseAmount + accidentFactor + violationFactor + yearFactor;
        double premiumAmount = plan.equals("Premium") ? basicPremium * 1.5 : basicPremium;
        return new InsuranceQuoteResponseDTO("PolicyBazaar", basicPremium, premiumAmount);
    }
    
    public InsuranceQuoteResponseDTO calculateAcko(Vehicle vehicle, String plan) {
        double baseAmount = 1800;
        double accidentFactor = vehicle.getNoOfDrivingAccidents() * 250;
        double violationFactor = vehicle.getNoOfDrivingViolations() * 180;
        double yearFactor = (2025 - vehicle.getVehicleYear()) * 80;
        double basicPremium = baseAmount + accidentFactor + violationFactor + yearFactor;
        double premiumAmount = plan.equals("Premium") ? basicPremium * 1.6 : basicPremium;
        return new InsuranceQuoteResponseDTO("Acko", basicPremium, premiumAmount);
    }
    
    public InsuranceQuoteResponseDTO calculateIcici(Vehicle vehicle, String plan) {
        double baseAmount = 2200;
        double accidentFactor = vehicle.getNoOfDrivingAccidents() * 350;
        double violationFactor = vehicle.getNoOfDrivingViolations() * 220;
        double yearFactor = (2025 - vehicle.getVehicleYear()) * 120;
        double basicPremium = baseAmount + accidentFactor + violationFactor + yearFactor;
        double premiumAmount = plan.equals("Premium") ? basicPremium * 1.55 : basicPremium;
        return new InsuranceQuoteResponseDTO("ICICI", basicPremium, premiumAmount);
    }
    
    public InsuranceQuoteResponseDTO calculateDigit(Vehicle vehicle, String plan) {
        double baseAmount = 1900;
        double accidentFactor = vehicle.getNoOfDrivingAccidents() * 280;
        double violationFactor = vehicle.getNoOfDrivingViolations() * 190;
        double yearFactor = (2025 - vehicle.getVehicleYear()) * 90;
        double basicPremium = baseAmount + accidentFactor + violationFactor + yearFactor;
        double premiumAmount = plan.equals("Premium") ? basicPremium * 1.65 : basicPremium;
        return new InsuranceQuoteResponseDTO("Digit", basicPremium, premiumAmount);
    }
}
