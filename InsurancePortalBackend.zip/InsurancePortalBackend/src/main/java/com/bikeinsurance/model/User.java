package com.bikeinsurance.model;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // auto PK

    @Column(nullable = false, unique = true)
    private String userId; // 3 digit + 4 alphanumeric

    private String name;
    private String email;
    private String phone;

    public User() {}

    // -------- AUTO GENERATE BEFORE INSERT --------
    @PrePersist
    public void generateCustomUserId() {
        if (this.userId == null) {
            String digits = String.format("%03d", (int)(Math.random() * 900) + 100); // 100–999
            String chars = generateAlphaNumeric(4);
            this.userId = digits + chars; // Example: 487A3dX
        }
    }

    private String generateAlphaNumeric(int length) {
        String letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            int idx = (int) (Math.random() * letters.length());
            sb.append(letters.charAt(idx));
        }
        return sb.toString();
    }

    // -------- Getter & Setter --------
    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getUserId() { return userId; }

    public void setUserId(String userId) { this.userId = userId; }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }

    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }

    public void setPhone(String phone) { this.phone = phone; }
}
