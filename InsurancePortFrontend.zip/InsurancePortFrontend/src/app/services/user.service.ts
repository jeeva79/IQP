// src/app/services/user.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from '../models/user.model';
import { ApiResponse } from '../models/api-response.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = 'http://localhost:8080/api/user';

  constructor(private http: HttpClient) {}

  saveUser(user: User): Observable<User> {
    return this.http.post<ApiResponse<User>>(`${this.apiUrl}/save`, user)
      .pipe(map(response => {
        if (response.success) {
          return {
            ...user,
            userId: response.userId!
          };
        }
        throw new Error(response.message || 'Failed to save user');
      }));
  }

  getUserByUserId(userId: string): Observable<User> {
    return this.http.get<ApiResponse<User>>(`${this.apiUrl}/show/${userId}`)
      .pipe(map(response => {
        if (response.success) {
          return {
            userId: response.userId!,
            name: response.data?.name || '',
            email: response.data?.email || '',
            phone: response.data?.phone || ''
          } as User;
        }
        throw new Error(response.message || 'User not found');
      }));
  }

  updateUser(userId: string, updates: Partial<User>): Observable<User> {
    return this.http.put<ApiResponse<User>>(`${this.apiUrl}/update/${userId}`, updates)
      .pipe(map(response => {
        if (response.success) {
          return { userId, ...updates } as User;
        }
        throw new Error(response.message || 'Failed to update user');
      }));
  }
}