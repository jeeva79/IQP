package com.bikeinsurance.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InsuranceQuoteResponseDTO {
    private String providerName;
    private Double basic;
    private Double premium;
}
