package com.bikeinsurance.service;

import com.bikeinsurance.model.User;
import com.bikeinsurance.dto.UserDTO;
import com.bikeinsurance.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Save new User
    public User saveUser(UserDTO userDTO) {
        User user = new User();
        user.setName(userDTO.getName());
        user.setEmail(userDTO.getEmail());
        user.setPhone(userDTO.getPhone());

        return userRepository.save(user);  // @PrePersist generates userId
    }

    // Get by custom userId
    public User getUserByUserId(String userId) {
        return userRepository.findByUserId(userId);
    }

    // Get by email
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    // Update user
    public User updateUser(String userId, Map<String, String> updates) {
        User user = userRepository.findByUserId(userId);
        if (user == null) return null;

        if (updates.containsKey("name"))
            user.setName(updates.get("name"));

        if (updates.containsKey("email"))
            user.setEmail(updates.get("email"));

        if (updates.containsKey("phone"))
            user.setPhone(updates.get("phone"));

        return userRepository.save(user);
    }
}
