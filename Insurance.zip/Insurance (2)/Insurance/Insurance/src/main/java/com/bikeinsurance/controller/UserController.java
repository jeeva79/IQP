package com.bikeinsurance.controller;
import com.bikeinsurance.model.User;
import com.bikeinsurance.dto.UserDTO;
import com.bikeinsurance.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "*")
public class UserController {
    @Autowired
    private UserService userService;
    
    @PostMapping("/save")
    public ResponseEntity<Map<String, Object>> saveUser(@RequestBody UserDTO userDTO) {
        try {
            User user = userService.saveUser(userDTO);
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("userId", user.getId());
            response.put("userIdGenerated", user.getUserId());
            response.put("message", "User details saved successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                Map.of("success", false, "message", e.getMessage())
            );
        }
    }
    
    @GetMapping("/show/{userId}")
    public ResponseEntity<Map<String, Object>> showUser(@PathVariable String userId) {
        try {
            User user = userService.getUserByUserId(userId);
            if (user == null) {
                return ResponseEntity.badRequest().body(
                    Map.of("success", false, "message", "User not found")
                );
            }
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("userId", user.getUserId());
            response.put("name", user.getName());
            response.put("email", user.getEmail());
            response.put("phone", user.getPhone());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                Map.of("success", false, "message", e.getMessage())
            );
        }
    }
    
    @PutMapping("/update/{userId}")
    public ResponseEntity<Map<String, Object>> updateUser(
            @PathVariable String userId,
            @RequestBody Map<String, String> updates) {
        try {
            User user = userService.updateUser(userId, updates);
            if (user == null) {
                return ResponseEntity.badRequest().body(
                    Map.of("success", false, "message", "User not found")
                );
            }
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "User updated successfully");
            response.put("userId", user.getUserId());
            response.put("email", user.getEmail());
            response.put("phone", user.getPhone());
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                Map.of("success", false, "message", e.getMessage())
            );
        }
    }
}