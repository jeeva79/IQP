package com.bikeinsurance.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "vehicles")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Vehicle {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false, unique = true)
    private String vehicleNumber;
    
    @Column(nullable = false)
    private Integer vehicleYear;
    
    @Column(nullable = false)
    private Integer noOfDrivingAccidents;
    
    @Column(nullable = false)
    private Integer noOfDrivingViolations;
    
    @Column(nullable = false)
    private String coverageType;
    
    @Column(nullable = false)
    private Double coverageAmount;
    
    @Column(nullable = false)
    private Double coverageDeductibles;
    
    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
    
    @OneToOne(mappedBy = "vehicle", cascade = CascadeType.ALL)
    private InsuranceQuote insuranceQuote;
}
