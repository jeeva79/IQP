# Bike Insurance System - Backend

This is a Spring Boot backend for a bike insurance application. It includes entities, DTOs, repositories, services and controllers.

Quick setup:

1. Ensure Java 17 and Maven are installed.
2. Create PostgreSQL database `bike_insurance_db` and update credentials in `src/main/resources/application.yaml`.

SQL:

```
CREATE DATABASE bike_insurance_db;
```

3. Create uploads directory (the app will attempt to create it at runtime):

On Windows PowerShell:

```powershell
mkdir -Force uploads\kyc
```

4. Build and run:

```powershell
mvn clean package
mvn spring-boot:run
```

APIs available (examples):

- POST `/api/vehicle/register` - register vehicle
- GET `/api/insurance/calculate/{vehicleId}` - get quotes
- POST `/api/insurance/select-provider` - select provider and create application
- POST `/api/user/save` - save user
- POST `/api/kyc/upload/{quoteId}` - upload KYC (multipart/form-data)
- GET `/api/admin/allApplications` - admin view
