package com.bikeinsurance.controller;

import com.bikeinsurance.model.InsuranceQuote;
import com.bikeinsurance.dto.AdminApplicationViewDTO;
import com.bikeinsurance.service.InsuranceQuoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:4200")
public class AdminController {
    @Autowired
    private InsuranceQuoteService quoteService;
    
    @GetMapping("/allApplications")
    public ResponseEntity<Map<String, Object>> getAllApplications() {
        try {
            List<InsuranceQuote> applications = quoteService.getAllApplications();
            List<AdminApplicationViewDTO> result = new ArrayList<>();
            
            for (InsuranceQuote app : applications) {
                AdminApplicationViewDTO dto = new AdminApplicationViewDTO(
                    app.getId(),
                    app.getUser().getName(),
                    app.getUser().getEmail(),
                    app.getVehicle().getVehicleNumber(),
                    app.getSelectedProvider(),
                    app.getSelectedPlan(),
                    app.getPremiumAmount(),
                    app.getKyc() != null ? app.getKyc().getVerificationStatus() : "NOT_UPLOADED",
                    app.getAppliedAt().toString()
                );
                result.add(dto);
            }
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("applications", result);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(
                Map.of("success", false, "message", e.getMessage())
            );
        }
    }
}
