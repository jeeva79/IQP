package com.bikeinsurance.controller;

import com.bikeinsurance.model.InsuranceQuote;
import com.bikeinsurance.dto.InsuranceApplicationDTO;
import com.bikeinsurance.dto.InsuranceQuoteResponseDTO;
import com.bikeinsurance.service.InsuranceQuoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/insurance")
@CrossOrigin(origins = "*")
public class InsuranceController {

    @Autowired
    private InsuranceQuoteService quoteService;

    @GetMapping("/calculate/{vehicleId}")
    public ResponseEntity<?> calculateQuotes(@PathVariable Long vehicleId) {
        try {

            List<InsuranceQuoteResponseDTO> quotes = quoteService.getQuotes(vehicleId);

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "quotes", quotes
            ));

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", e.getMessage()
            ));
        }
    }


    @PostMapping("/select-provider")
    public ResponseEntity<?> selectProvider(@RequestBody InsuranceApplicationDTO appDTO) {
        try {

            InsuranceQuote quote = quoteService.saveQuote(
                    appDTO.getUserId(),
                    appDTO.getVehicleId(),
                    appDTO.getSelectedProvider(),
                    appDTO.getSelectedPlan(),
          appDTO.getPremiumAmount()
            );

            return ResponseEntity.ok(Map.of(
                    "success", true,
                    "quoteId", quote.getId(),
                    "message", "Provider selected successfully"
            ));

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of(
                    "success", false,
                    "message", e.getMessage()
            ));
        }
    }
}
