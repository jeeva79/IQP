import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { Vehicle } from '../models/vehicle.model';
import { ApiResponse } from '../models/api-response.model';

@Injectable({
  providedIn: 'root'
})
export class VehicleService {
  private apiUrl = 'http://localhost:8080/api/vehicle';

  constructor(private http: HttpClient) {}

  saveVehicle(vehicle: Vehicle): Observable<Vehicle> {
    return this.http.post<ApiResponse<Vehicle>>(`${this.apiUrl}/register`, vehicle)
      .pipe(
        map(response => {
          
          console.log("response : " + response)
          if (response.success && response.data) {
            console.log("Data : " + response.data)
            return response.data; // return saved vehicle from response
          }else
          throw new Error(response.message || 'Failed to save vehicle');
        }),
        catchError(error => {
          console.error('Vehicle save error:', error);
          return throwError(() => new Error(error.error?.message || 'Failed to save vehicle'));
        })
      );
  }

  getVehicleByNumber(vehicleNumber: string): Observable<Vehicle> {
    return this.http.get<ApiResponse<Vehicle>>(`${this.apiUrl}/show/${vehicleNumber}`)
      .pipe(
        map(response => {
          if (response.success && response.data) {
            return response.data; // data contains the Vehicle object
          }
          throw new Error(response.message || 'Vehicle not found');
        }),
        catchError(error => {
          console.error('Vehicle fetch error:', error);
          return throwError(() => new Error('Vehicle not found'));
        })
      );
  }

  updateVehicle(vehicleNumber: string, vehicle: Vehicle): Observable<Vehicle> {
    return this.http.put<ApiResponse<Vehicle>>(`${this.apiUrl}/update/${vehicleNumber}`, vehicle)
      .pipe(
        map(response => {
          if (response.success && response.data) {
            return response.data; // return updated vehicle
          }
          throw new Error(response.message || 'Failed to update vehicle');
        }),
        catchError(error => {
          console.error('Vehicle update error:', error);
          return throwError(() => new Error(error.error?.message || 'Failed to update vehicle'));
        })
      );
  }
}
