package com.bikeinsurance.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "insurance_quotes")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class InsuranceQuote {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @OneToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @OneToOne
    @JoinColumn(name = "vehicle_id", nullable = false)
    private Vehicle vehicle;
    
    @Column(nullable = false)
    private String selectedProvider;
    
    @Column(nullable = false)
    private String selectedPlan;
    
    @Column(nullable = false)
    private Double premiumAmount;
    
    @Column(nullable = false)
    private String status;
    
    @Column(nullable = false, updatable = false)
    private LocalDateTime appliedAt = LocalDateTime.now();
    
    @OneToOne(mappedBy = "insuranceQuote", cascade = CascadeType.ALL)
    private KYC kyc;
}
