import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpEventType } from '@angular/common/http';
import { KycService } from '../../services/kyc.service';

@Component({
  selector: 'app-kyc-upload',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container mt-5">
      <div class="card">
        <div class="card-header bg-warning text-dark">
          <h3 class="mb-0">KYC Document Upload</h3>
        </div>
        <div class="card-body">
          <div class="alert alert-info">
            <strong>Provider:</strong> {{ provider }}<br>
            <strong>Vehicle:</strong> {{ vehicleNumber }}
          </div>

          <div *ngIf="errorMessage" class="alert alert-danger">
            {{ errorMessage }}
          </div>

          <form (ngSubmit)="uploadKyc()">
            <div class="mb-3">
              <label class="form-label">Driving License (PDF) *</label>
              <input 
                type="file" 
                class="form-control" 
                accept=".pdf"
                (change)="onFileSelected($event, 'drivingLicense')"
                required>
              <small class="text-muted">Max size: 5MB</small>
            </div>

            <div class="mb-3">
              <label class="form-label">RC Document (PDF) *</label>
              <input 
                type="file" 
                class="form-control" 
                accept=".pdf"
                (change)="onFileSelected($event, 'rc')"
                required>
              <small class="text-muted">Max size: 5MB</small>
            </div>

            <div class="mb-3">
              <label class="form-label">Aadhar Card (PDF) *</label>
              <input 
                type="file" 
                class="form-control" 
                accept=".pdf"
                (change)="onFileSelected($event, 'aadhar')"
                required>
              <small class="text-muted">Max size: 5MB</small>
            </div>

            <div *ngIf="uploadProgress > 0 && uploadProgress < 100" class="mb-3">
              <label>Upload Progress: {{ uploadProgress }}%</label>
              <div class="progress">
                <div 
                  class="progress-bar progress-bar-striped progress-bar-animated" 
                  role="progressbar" 
                  [style.width.%]="uploadProgress">
                </div>
              </div>
            </div>

            <button 
              type="submit" 
              class="btn btn-warning text-dark w-100"
              [disabled]="!allFilesSelected() || uploading">
              {{ uploading ? 'Uploading...' : 'Upload KYC Documents' }}
            </button>
          </form>
        </div>
      </div>
    </div>
  `
})
export class KycUploadComponent implements OnInit {
  quoteId: number = 0;
  vehicleNumber: string = '';
  provider: string = '';
  
  drivingLicenseFile: File | null = null;
  rcFile: File | null = null;
  aadharFile: File | null = null;
  
  uploadProgress: number = 0;
  errorMessage: string = '';
  uploading: boolean = false;

  constructor(
    private kycService: KycService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.quoteId = Number(params['quoteId']);
      this.vehicleNumber = params['vehicleNumber'] || '';
      this.provider = params['provider'] || '';
    });
  }

  onFileSelected(event: any, type: 'drivingLicense' | 'rc' | 'aadhar'): void {
    const file: File = event.target.files[0];
    if (file) {
      // Validate file size (5MB max)
      if (file.size > 5 * 1024 * 1024) {
        this.errorMessage = `File ${file.name} exceeds 5MB limit.`;
        return;
      }

      // Validate PDF
      if (file.type !== 'application/pdf') {
        this.errorMessage = `File ${file.name} must be a PDF.`;
        return;
      }

      this.errorMessage = '';

      if (type === 'drivingLicense') {
        this.drivingLicenseFile = file;
      } else if (type === 'rc') {
        this.rcFile = file;
      } else if (type === 'aadhar') {
        this.aadharFile = file;
      }
    }
  }

  allFilesSelected(): boolean {
    return !!(this.drivingLicenseFile && this.rcFile && this.aadharFile);
  }

  uploadKyc(): void {
    if (!this.allFilesSelected()) {
      this.errorMessage = 'Please select all three KYC documents.';
      return;
    }

    this.uploading = true;
    this.errorMessage = '';

    this.kycService.uploadKyc(this.quoteId, {
      drivingLicense: this.drivingLicenseFile!,
      rc: this.rcFile!,
      aadhar: this.aadharFile!
    }).subscribe({
      next: (event) => {
        if (event.type === HttpEventType.UploadProgress && event.total) {
          this.uploadProgress = Math.round((100 * event.loaded) / event.total);
        } else if (event.type === HttpEventType.Response) {
          this.uploading = false;
          this.router.navigate(['/success'], {
            queryParams: { 
              quoteId: this.quoteId,
              vehicleNumber: this.vehicleNumber 
            }
          });
        }
      },
      error: (err) => {
        console.error('KYC upload failed:', err);
        this.errorMessage = err.error?.message || 'KYC upload failed. Please try again.';
        this.uploading = false;
        this.uploadProgress = 0;
      }
    });
  }
}
