package com.Insurance.service;

import com.Insurance.model.User;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final List<User> users = new ArrayList<>();
    private long idCounter = 1;

    public User saveUser(User user) {
        user.setId(idCounter++); // Auto-increment ID
        users.add(user);
        return user;
    }

    public User updateUser(User user) {
        Optional<User> existingUser = getUserById(user.getId());

        if (existingUser.isPresent()) {
            users.remove(existingUser.get());
        } else {
            throw new RuntimeException("User not found with ID: " + user.getId());
        }

        users.add(user);
        return user;
    }

    public Optional<User> getUserById(Long id) {
        return users.stream()
                .filter(u -> u.getId() != null && u.getId().equals(id))
                .findFirst();
    }

    public List<User> getAllUsers() {
        return new ArrayList<>(users);
    }
}
