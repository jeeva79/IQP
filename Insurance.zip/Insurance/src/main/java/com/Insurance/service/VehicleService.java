package com.Insurance.service;

import com.Insurance.model.Vehicle;
import com.Insurance.repository.VehicleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VehicleService {

    @Autowired
    private VehicleRepository vehicleRepository;

    public List<Vehicle> getAllVehicles() {
        return vehicleRepository.findAll();
    }

    public Optional<Vehicle> getVehicleByNumber(String vehicleNumber) {
        return vehicleRepository.findById(vehicleNumber);
    }

    public Vehicle saveVehicle(Vehicle vehicle) {
        return vehicleRepository.save(vehicle);
    }

    public void deleteVehicle(String vehicleNumber) {
        vehicleRepository.deleteById(vehicleNumber);
    }

    public Vehicle updateVehicle(Vehicle vehicle) {
        Optional<Vehicle> existingVehicle = vehicleRepository.findById(vehicle.getVehicleNumber());
        if (existingVehicle.isPresent()) {
            Vehicle updatedVehicle = existingVehicle.get();
            updatedVehicle.setVehicleModel(vehicle.getVehicleModel());
            updatedVehicle.setVehicleMake(vehicle.getVehicleMake());
            updatedVehicle.setVehicleYear(vehicle.getVehicleYear());
            updatedVehicle.setVehicleType(vehicle.getVehicleType());
            updatedVehicle.setFuelType(vehicle.getFuelType());
            return vehicleRepository.save(updatedVehicle);
        }
        throw new RuntimeException("Vehicle not found");
    }
}