package com.Insurance.controller;

import com.Insurance.model.InsuranceQuote;
import com.Insurance.service.InsuranceQuoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/insurance-quotes")
public class InsuranceQuoteController {

    @Autowired
    private InsuranceQuoteService insuranceQuoteService;

    // ---------------------- Update existing quote ----------------------
    @PutMapping("/requote")
    public ResponseEntity<InsuranceQuote> requote(@RequestBody InsuranceQuote quote) {
        return ResponseEntity.ok(insuranceQuoteService.updateInsuranceQuote(quote));
    }

    // ---------------------- Show all quotes with user & vehicle details ----------------------
    @GetMapping("/store")
    public ResponseEntity<List<InsuranceQuote>> store() {
        return ResponseEntity.ok(insuranceQuoteService.getAllInsuranceQuotes());
    }

    // ---------------------- Show all vehicle numbers from quotes ----------------------
    @GetMapping("/history")
    public ResponseEntity<List<String>> history() {
        List<String> vehicleNumbers = insuranceQuoteService.getAllInsuranceQuotes()
                .stream()
                .map(q -> q.getVehicle().getVehicleNumber()) // lambda to access vehicleNumber
                .collect(Collectors.toList());

        return ResponseEntity.ok(vehicleNumbers);
    }

    // ---------------------- Generate quote with premium calculation ----------------------
    @PostMapping("/generate")
    public ResponseEntity<InsuranceQuote> generate(@RequestBody InsuranceQuote quote) {
        return ResponseEntity.ok(insuranceQuoteService.generateQuote(quote));
    }
}
